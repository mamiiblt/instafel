.class public Linstafel/app/ota/tasks/VersionTask;
.super Landroid/os/AsyncTask;
.source "VersionTask.java"


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Landroid/os/AsyncTask<",
        "Ljava/lang/String;",
        "Ljava/lang/Void;",
        "Ljava/lang/String;",
        ">;"
    }
.end annotation


# instance fields
.field private final act:Landroid/app/Activity;

.field private checkType:Z

.field private ifl_type:Ljava/lang/String;

.field private ifl_version:I

.field private instafelDialog:Linstafel/app/utils/dialog/InstafelDialog;


# direct methods
.method public constructor <init>(Landroid/app/Activity;Ljava/lang/String;IZ)V
    .locals 0

    invoke-direct {p0}, Landroid/os/AsyncTask;-><init>()V

    iput-object p2, p0, Linstafel/app/ota/tasks/VersionTask;->ifl_type:Ljava/lang/String;

    iput p3, p0, Linstafel/app/ota/tasks/VersionTask;->ifl_version:I

    new-instance p2, Linstafel/app/utils/dialog/InstafelDialog;

    invoke-direct {p2, p1}, Linstafel/app/utils/dialog/InstafelDialog;-><init>(Landroid/app/Activity;)V

    iput-object p2, p0, Linstafel/app/ota/tasks/VersionTask;->instafelDialog:Linstafel/app/utils/dialog/InstafelDialog;

    iput-object p1, p0, Linstafel/app/ota/tasks/VersionTask;->act:Landroid/app/Activity;

    iput-boolean p4, p0, Linstafel/app/ota/tasks/VersionTask;->checkType:Z

    return-void
.end method

.method private sendGetRequest(Ljava/lang/String;)Ljava/lang/String;
    .locals 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    new-instance v0, Ljava/net/URL;

    invoke-direct {v0, p1}, Ljava/net/URL;-><init>(Ljava/lang/String;)V

    invoke-virtual {v0}, Ljava/net/URL;->openConnection()Ljava/net/URLConnection;

    move-result-object p1

    check-cast p1, Ljava/net/HttpURLConnection;

    const/16 v0, 0x3a98

    invoke-virtual {p1, v0}, Ljava/net/HttpURLConnection;->setConnectTimeout(I)V

    :try_start_0
    invoke-virtual {p1}, Ljava/net/HttpURLConnection;->getInputStream()Ljava/io/InputStream;

    move-result-object v0

    new-instance v1, Ljava/io/BufferedReader;

    new-instance v2, Ljava/io/InputStreamReader;

    invoke-direct {v2, v0}, Ljava/io/InputStreamReader;-><init>(Ljava/io/InputStream;)V

    invoke-direct {v1, v2}, Ljava/io/BufferedReader;-><init>(Ljava/io/Reader;)V

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    :goto_0
    invoke-virtual {v1}, Ljava/io/BufferedReader;->readLine()Ljava/lang/String;

    move-result-object v2

    if-eqz v2, :cond_0

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    goto :goto_0

    :cond_0
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    invoke-virtual {p1}, Ljava/net/HttpURLConnection;->disconnect()V

    return-object v0

    :catchall_0
    move-exception v0

    invoke-virtual {p1}, Ljava/net/HttpURLConnection;->disconnect()V

    throw v0
.end method


# virtual methods
.method protected bridge synthetic doInBackground([Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    check-cast p1, [Ljava/lang/String;

    invoke-virtual {p0, p1}, Linstafel/app/ota/tasks/VersionTask;->doInBackground([Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    return-object p1
.end method

.method protected varargs doInBackground([Ljava/lang/String;)Ljava/lang/String;
    .locals 1

    const/4 v0, 0x0

    :try_start_0
    aget-object p1, p1, v0

    invoke-direct {p0, p1}, Linstafel/app/ota/tasks/VersionTask;->sendGetRequest(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1
    :try_end_0
    .catch Ljava/io/IOException; {:try_start_0 .. :try_end_0} :catch_0

    return-object p1

    :catch_0
    move-exception p1

    invoke-virtual {p1}, Ljava/io/IOException;->printStackTrace()V

    const-string p1, "Couldn\'t connect to the server"

    return-object p1
.end method

.method protected bridge synthetic onPostExecute(Ljava/lang/Object;)V
    .locals 0

    check-cast p1, Ljava/lang/String;

    invoke-virtual {p0, p1}, Linstafel/app/ota/tasks/VersionTask;->onPostExecute(Ljava/lang/String;)V

    return-void
.end method

.method protected onPostExecute(Ljava/lang/String;)V
    .locals 8

    :try_start_0
    iget-object v0, p0, Linstafel/app/ota/tasks/VersionTask;->act:Landroid/app/Activity;

    invoke-static {v0}, Linstafel/app/ota/LastCheck;->update(Landroid/app/Activity;)V

    iget-boolean v0, p0, Linstafel/app/ota/tasks/VersionTask;->checkType:Z

    if-eqz v0, :cond_0

    iget-object v0, p0, Linstafel/app/ota/tasks/VersionTask;->act:Landroid/app/Activity;

    invoke-static {v0}, Linstafel/app/ota/LastCheck;->updateUi(Landroid/app/Activity;)V

    :cond_0
    new-instance v0, Lorg/json/JSONObject;

    invoke-direct {v0, p1}, Lorg/json/JSONObject;-><init>(Ljava/lang/String;)V

    const-string p1, "releases"

    invoke-virtual {v0, p1}, Lorg/json/JSONObject;->getJSONArray(Ljava/lang/String;)Lorg/json/JSONArray;

    move-result-object p1

    const/4 v0, 0x0

    move v1, v0

    :goto_0
    invoke-virtual {p1}, Lorg/json/JSONArray;->length()I

    move-result v2

    if-ge v1, v2, :cond_2

    invoke-virtual {p1, v1}, Lorg/json/JSONArray;->getJSONArray(I)Lorg/json/JSONArray;

    move-result-object v2

    const/4 v3, 0x4

    invoke-virtual {v2, v3, v0}, Lorg/json/JSONArray;->optBoolean(IZ)Z

    move-result v3

    if-nez v3, :cond_1

    invoke-virtual {v2, v0}, Lorg/json/JSONArray;->getInt(I)I

    move-result p1

    move v5, p1

    goto :goto_1

    :cond_1
    add-int/lit8 v1, v1, 0x1

    goto :goto_0

    :cond_2
    move v5, v0

    :goto_1
    if-nez v5, :cond_3

    return-void

    :cond_3
    new-instance v1, Linstafel/app/ota/tasks/BuildInfoTask;

    iget-object v2, p0, Linstafel/app/ota/tasks/VersionTask;->act:Landroid/app/Activity;

    iget v3, p0, Linstafel/app/ota/tasks/VersionTask;->ifl_version:I

    iget-object v4, p0, Linstafel/app/ota/tasks/VersionTask;->ifl_type:Ljava/lang/String;

    iget-object v6, p0, Linstafel/app/ota/tasks/VersionTask;->instafelDialog:Linstafel/app/utils/dialog/InstafelDialog;

    iget-boolean v7, p0, Linstafel/app/ota/tasks/VersionTask;->checkType:Z

    invoke-direct/range {v1 .. v7}, Linstafel/app/ota/tasks/BuildInfoTask;-><init>(Landroid/app/Activity;ILjava/lang/String;ILinstafel/app/utils/dialog/InstafelDialog;Z)V

    const/4 p1, 0x1

    new-array p1, p1, [Ljava/lang/String;

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const-string v3, "https://api.mamii.dev/content/rels/get/"

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2, v5}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    aput-object v2, p1, v0

    invoke-virtual {v1, p1}, Linstafel/app/ota/tasks/BuildInfoTask;->execute([Ljava/lang/Object;)Landroid/os/AsyncTask;
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    return-void

    :catch_0
    move-exception v0

    move-object p1, v0

    invoke-virtual {p1}, Ljava/lang/Exception;->printStackTrace()V

    return-void
.end method

.method protected onPreExecute()V
    .locals 5

    invoke-super {p0}, Landroid/os/AsyncTask;->onPreExecute()V

    iget-boolean v0, p0, Linstafel/app/ota/tasks/VersionTask;->checkType:Z

    if-eqz v0, :cond_0

    iget-object v0, p0, Linstafel/app/ota/tasks/VersionTask;->instafelDialog:Linstafel/app/utils/dialog/InstafelDialog;

    const-string v1, "top_space"

    const/16 v2, 0x19

    invoke-virtual {v0, v1, v2}, Linstafel/app/utils/dialog/InstafelDialog;->addSpace(Ljava/lang/String;I)V

    new-instance v0, Linstafel/app/ui/LoadingBar;

    iget-object v1, p0, Linstafel/app/ota/tasks/VersionTask;->act:Landroid/app/Activity;

    invoke-direct {v0, v1}, Linstafel/app/ui/LoadingBar;-><init>(Landroid/content/Context;)V

    new-instance v1, Landroid/view/ViewGroup$MarginLayoutParams;

    const/4 v3, -0x2

    invoke-direct {v1, v3, v3}, Landroid/view/ViewGroup$MarginLayoutParams;-><init>(II)V

    iget-object v3, p0, Linstafel/app/ota/tasks/VersionTask;->act:Landroid/app/Activity;

    invoke-virtual {v3}, Landroid/app/Activity;->getResources()Landroid/content/res/Resources;

    move-result-object v3

    invoke-virtual {v3}, Landroid/content/res/Resources;->getDisplayMetrics()Landroid/util/DisplayMetrics;

    move-result-object v3

    iget v3, v3, Landroid/util/DisplayMetrics;->density:F

    const/high16 v4, 0x41c80000    # 25.0f

    mul-float/2addr v3, v4

    const/high16 v4, 0x3f000000    # 0.5f

    add-float/2addr v3, v4

    float-to-int v3, v3

    const/4 v4, 0x0

    invoke-virtual {v1, v3, v4, v3, v4}, Landroid/view/ViewGroup$MarginLayoutParams;->setMargins(IIII)V

    invoke-virtual {v0, v1}, Linstafel/app/ui/LoadingBar;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    iget-object v1, p0, Linstafel/app/ota/tasks/VersionTask;->instafelDialog:Linstafel/app/utils/dialog/InstafelDialog;

    const-string v3, "loading_bar"

    invoke-virtual {v1, v3, v0}, Linstafel/app/utils/dialog/InstafelDialog;->addCustomView(Ljava/lang/String;Landroid/view/View;)V

    iget-object v0, p0, Linstafel/app/ota/tasks/VersionTask;->instafelDialog:Linstafel/app/utils/dialog/InstafelDialog;

    const-string v1, "button_top_space"

    invoke-virtual {v0, v1, v2}, Linstafel/app/utils/dialog/InstafelDialog;->addSpace(Ljava/lang/String;I)V

    iget-object v0, p0, Linstafel/app/ota/tasks/VersionTask;->instafelDialog:Linstafel/app/utils/dialog/InstafelDialog;

    invoke-virtual {v0}, Linstafel/app/utils/dialog/InstafelDialog;->show()V

    :cond_0
    return-void
.end method
