.class public Linstafel/app/ota/tasks/BuildInfoTask;
.super Landroid/os/AsyncTask;
.source "BuildInfoTask.java"


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Landroid/os/AsyncTask<",
        "Ljava/lang/String;",
        "Ljava/lang/Void;",
        "Ljava/lang/String;",
        ">;"
    }
.end annotation


# instance fields
.field private final act:Landroid/app/Activity;

.field checkType:Z

.field ifl_type:Ljava/lang/String;

.field ifl_version:I

.field instafelDialog:Linstafel/app/utils/dialog/InstafelDialog;

.field lastVersion:I

.field versionDialog:Linstafel/app/utils/dialog/InstafelDialog;


# direct methods
.method public constructor <init>(Landroid/app/Activity;ILjava/lang/String;ILinstafel/app/utils/dialog/InstafelDialog;Z)V
    .locals 0

    invoke-direct {p0}, Landroid/os/AsyncTask;-><init>()V

    iput p4, p0, Linstafel/app/ota/tasks/BuildInfoTask;->lastVersion:I

    iput p2, p0, Linstafel/app/ota/tasks/BuildInfoTask;->ifl_version:I

    iput-object p3, p0, Linstafel/app/ota/tasks/BuildInfoTask;->ifl_type:Ljava/lang/String;

    iput-object p1, p0, Linstafel/app/ota/tasks/BuildInfoTask;->act:Landroid/app/Activity;

    iput-object p5, p0, Linstafel/app/ota/tasks/BuildInfoTask;->versionDialog:Linstafel/app/utils/dialog/InstafelDialog;

    new-instance p2, Linstafel/app/utils/dialog/InstafelDialog;

    invoke-direct {p2, p1}, Linstafel/app/utils/dialog/InstafelDialog;-><init>(Landroid/app/Activity;)V

    iput-object p2, p0, Linstafel/app/ota/tasks/BuildInfoTask;->instafelDialog:Linstafel/app/utils/dialog/InstafelDialog;

    iput-boolean p6, p0, Linstafel/app/ota/tasks/BuildInfoTask;->checkType:Z

    return-void
.end method

.method static synthetic access$000(Linstafel/app/ota/tasks/BuildInfoTask;)Landroid/app/Activity;
    .locals 0

    iget-object p0, p0, Linstafel/app/ota/tasks/BuildInfoTask;->act:Landroid/app/Activity;

    return-object p0
.end method

.method private sendGetRequest(Ljava/lang/String;)Ljava/lang/String;
    .locals 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    new-instance v0, Ljava/net/URL;

    invoke-direct {v0, p1}, Ljava/net/URL;-><init>(Ljava/lang/String;)V

    invoke-virtual {v0}, Ljava/net/URL;->openConnection()Ljava/net/URLConnection;

    move-result-object p1

    check-cast p1, Ljava/net/HttpURLConnection;

    const/16 v0, 0x3a98

    invoke-virtual {p1, v0}, Ljava/net/HttpURLConnection;->setConnectTimeout(I)V

    :try_start_0
    invoke-virtual {p1}, Ljava/net/HttpURLConnection;->getInputStream()Ljava/io/InputStream;

    move-result-object v0

    new-instance v1, Ljava/io/BufferedReader;

    new-instance v2, Ljava/io/InputStreamReader;

    invoke-direct {v2, v0}, Ljava/io/InputStreamReader;-><init>(Ljava/io/InputStream;)V

    invoke-direct {v1, v2}, Ljava/io/BufferedReader;-><init>(Ljava/io/Reader;)V

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    :goto_0
    invoke-virtual {v1}, Ljava/io/BufferedReader;->readLine()Ljava/lang/String;

    move-result-object v2

    if-eqz v2, :cond_0

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    goto :goto_0

    :cond_0
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    invoke-virtual {p1}, Ljava/net/HttpURLConnection;->disconnect()V

    return-object v0

    :catchall_0
    move-exception v0

    invoke-virtual {p1}, Ljava/net/HttpURLConnection;->disconnect()V

    throw v0
.end method


# virtual methods
.method protected bridge synthetic doInBackground([Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    check-cast p1, [Ljava/lang/String;

    invoke-virtual {p0, p1}, Linstafel/app/ota/tasks/BuildInfoTask;->doInBackground([Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    return-object p1
.end method

.method protected varargs doInBackground([Ljava/lang/String;)Ljava/lang/String;
    .locals 2

    const/4 v0, 0x0

    :try_start_0
    aget-object p1, p1, v0

    invoke-direct {p0, p1}, Linstafel/app/ota/tasks/BuildInfoTask;->sendGetRequest(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1
    :try_end_0
    .catch Ljava/io/IOException; {:try_start_0 .. :try_end_0} :catch_0

    return-object p1

    :catch_0
    move-exception p1

    invoke-virtual {p1}, Ljava/io/IOException;->printStackTrace()V

    const-string v0, "Instafel"

    invoke-virtual {p1}, Ljava/io/IOException;->getMessage()Ljava/lang/String;

    move-result-object v1

    invoke-static {v0, v1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    new-instance v0, Ljava/lang/StringBuilder;

    const-string v1, "Error: "

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {p1}, Ljava/io/IOException;->getMessage()Ljava/lang/String;

    move-result-object p1

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object p1

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    return-object p1
.end method

.method protected bridge synthetic onPostExecute(Ljava/lang/Object;)V
    .locals 0

    check-cast p1, Ljava/lang/String;

    invoke-virtual {p0, p1}, Linstafel/app/ota/tasks/BuildInfoTask;->onPostExecute(Ljava/lang/String;)V

    return-void
.end method

.method protected onPostExecute(Ljava/lang/String;)V
    .locals 19

    move-object/from16 v1, p0

    iget-object v0, v1, Linstafel/app/ota/tasks/BuildInfoTask;->versionDialog:Linstafel/app/utils/dialog/InstafelDialog;

    invoke-virtual {v0}, Linstafel/app/utils/dialog/InstafelDialog;->dismiss()V

    :try_start_0
    new-instance v0, Lorg/json/JSONObject;

    move-object/from16 v2, p1

    invoke-direct {v0, v2}, Lorg/json/JSONObject;-><init>(Ljava/lang/String;)V

    const-string v2, "patcherData"

    invoke-virtual {v0, v2}, Lorg/json/JSONObject;->getJSONObject(Ljava/lang/String;)Lorg/json/JSONObject;

    move-result-object v2

    const-string v3, "igVersion"

    invoke-virtual {v2, v3}, Lorg/json/JSONObject;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    iget-object v3, v1, Linstafel/app/ota/tasks/BuildInfoTask;->ifl_type:Ljava/lang/String;

    const-string v4, "Unclone"

    invoke-virtual {v3, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    const-string v4, "fileName"

    const-string v5, "/"

    const-string v6, "fileUrl"

    const-string v7, "fileInfos"

    const-string v8, ""

    const-string v9, "https://cdn.mamii.dev/instafel/releases/v"

    if-eqz v3, :cond_1

    :try_start_1
    invoke-virtual {v0, v7}, Lorg/json/JSONObject;->getJSONObject(Ljava/lang/String;)Lorg/json/JSONObject;

    move-result-object v0

    const-string v3, "unclone"

    invoke-virtual {v0, v3}, Lorg/json/JSONObject;->getJSONObject(Ljava/lang/String;)Lorg/json/JSONObject;

    move-result-object v0

    invoke-virtual {v0, v6, v8}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/String;->isEmpty()Z

    move-result v6

    if-eqz v6, :cond_0

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3, v9}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    iget v6, v1, Linstafel/app/ota/tasks/BuildInfoTask;->lastVersion:I

    invoke-virtual {v3, v6}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v0, v4}, Lorg/json/JSONObject;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v3, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    move-object v8, v0

    goto :goto_0

    :cond_0
    move-object v8, v3

    goto :goto_0

    :cond_1
    iget-object v3, v1, Linstafel/app/ota/tasks/BuildInfoTask;->ifl_type:Ljava/lang/String;

    const-string v10, "Clone"

    invoke-virtual {v3, v10}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-eqz v3, :cond_2

    invoke-virtual {v0, v7}, Lorg/json/JSONObject;->getJSONObject(Ljava/lang/String;)Lorg/json/JSONObject;

    move-result-object v0

    const-string v3, "clone"

    invoke-virtual {v0, v3}, Lorg/json/JSONObject;->getJSONObject(Ljava/lang/String;)Lorg/json/JSONObject;

    move-result-object v0

    invoke-virtual {v0, v6, v8}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v8

    invoke-virtual {v8}, Ljava/lang/String;->isEmpty()Z

    move-result v3

    if-eqz v3, :cond_2

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3, v9}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    iget v6, v1, Linstafel/app/ota/tasks/BuildInfoTask;->lastVersion:I

    invoke-virtual {v3, v6}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v0, v4}, Lorg/json/JSONObject;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v3, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v8

    :cond_2
    :goto_0
    iget v0, v1, Linstafel/app/ota/tasks/BuildInfoTask;->lastVersion:I

    iget v3, v1, Linstafel/app/ota/tasks/BuildInfoTask;->ifl_version:I

    const/4 v4, 0x0

    if-le v0, v3, :cond_4

    iget-object v0, v1, Linstafel/app/ota/tasks/BuildInfoTask;->act:Landroid/app/Activity;

    invoke-static {v0}, Linstafel/app/utils/localization/LocalizationUtils;->getIflLocale(Landroid/content/Context;)Ljava/util/Locale;

    move-result-object v0

    iget-object v3, v1, Linstafel/app/ota/tasks/BuildInfoTask;->act:Landroid/app/Activity;

    invoke-static {v3}, Linstafel/app/utils/localization/LocalizationUtils;->getIflLocale(Landroid/content/Context;)Ljava/util/Locale;

    move-result-object v5

    const-string v6, "ifl_d1_02"

    iget v7, v1, Linstafel/app/ota/tasks/BuildInfoTask;->lastVersion:I

    invoke-static {v7}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v7

    filled-new-array {v7, v2}, [Ljava/lang/Object;

    move-result-object v2

    invoke-static {v3, v5, v6, v2}, Linstafel/app/utils/localization/LocalizedStringGetter;->getLocalizedString(Landroid/app/Activity;Ljava/util/Locale;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v2

    if-nez v2, :cond_3

    const-string v2, "ifl_err"

    :cond_3
    move-object v11, v2

    iget-object v2, v1, Linstafel/app/ota/tasks/BuildInfoTask;->instafelDialog:Linstafel/app/utils/dialog/InstafelDialog;

    const-string v3, "top_space"

    const/16 v5, 0x19

    invoke-virtual {v2, v3, v5}, Linstafel/app/utils/dialog/InstafelDialog;->addSpace(Ljava/lang/String;I)V

    iget-object v12, v1, Linstafel/app/ota/tasks/BuildInfoTask;->instafelDialog:Linstafel/app/utils/dialog/InstafelDialog;

    const-string v13, "dialog_title"

    iget-object v2, v1, Linstafel/app/ota/tasks/BuildInfoTask;->act:Landroid/app/Activity;

    const-string v3, "ifl_d1_01"

    new-array v5, v4, [Ljava/lang/Object;

    invoke-static {v2, v0, v3, v5}, Linstafel/app/utils/localization/LocalizedStringGetter;->getDialogLocalizedString(Landroid/app/Activity;Ljava/util/Locale;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v14

    sget v17, Linstafel/app/utils/dialog/InstafelDialogTextType;->TITLE:I

    new-instance v2, Linstafel/app/utils/dialog/InstafelDialogMargins;

    iget-object v3, v1, Linstafel/app/ota/tasks/BuildInfoTask;->act:Landroid/app/Activity;

    invoke-direct {v2, v3, v4, v4}, Linstafel/app/utils/dialog/InstafelDialogMargins;-><init>(Landroid/app/Activity;II)V

    const/16 v15, 0x1e

    const/16 v16, 0x0

    move-object/from16 v18, v2

    invoke-virtual/range {v12 .. v18}, Linstafel/app/utils/dialog/InstafelDialog;->addTextView(Ljava/lang/String;Ljava/lang/String;IIILinstafel/app/utils/dialog/InstafelDialogMargins;)V

    iget-object v2, v1, Linstafel/app/ota/tasks/BuildInfoTask;->instafelDialog:Linstafel/app/utils/dialog/InstafelDialog;

    const-string v3, "mid_space"

    const/16 v5, 0x14

    invoke-virtual {v2, v3, v5}, Linstafel/app/utils/dialog/InstafelDialog;->addSpace(Ljava/lang/String;I)V

    iget-object v9, v1, Linstafel/app/ota/tasks/BuildInfoTask;->instafelDialog:Linstafel/app/utils/dialog/InstafelDialog;

    const-string v10, "dialog_desc"

    sget v14, Linstafel/app/utils/dialog/InstafelDialogTextType;->DESCRIPTION:I

    new-instance v15, Linstafel/app/utils/dialog/InstafelDialogMargins;

    iget-object v2, v1, Linstafel/app/ota/tasks/BuildInfoTask;->act:Landroid/app/Activity;

    const/16 v3, 0x18

    invoke-direct {v15, v2, v3, v3}, Linstafel/app/utils/dialog/InstafelDialogMargins;-><init>(Landroid/app/Activity;II)V

    const/16 v12, 0x10

    const/16 v13, 0x136

    invoke-virtual/range {v9 .. v15}, Linstafel/app/utils/dialog/InstafelDialog;->addTextView(Ljava/lang/String;Ljava/lang/String;IIILinstafel/app/utils/dialog/InstafelDialogMargins;)V

    iget-object v2, v1, Linstafel/app/ota/tasks/BuildInfoTask;->instafelDialog:Linstafel/app/utils/dialog/InstafelDialog;

    const-string v3, "button_top_space"

    invoke-virtual {v2, v3, v5}, Linstafel/app/utils/dialog/InstafelDialog;->addSpace(Ljava/lang/String;I)V

    iget-object v9, v1, Linstafel/app/ota/tasks/BuildInfoTask;->instafelDialog:Linstafel/app/utils/dialog/InstafelDialog;

    const-string v10, "buttons"

    iget-object v2, v1, Linstafel/app/ota/tasks/BuildInfoTask;->act:Landroid/app/Activity;

    const-string v3, "ifl_d1_04"

    new-array v5, v4, [Ljava/lang/Object;

    invoke-static {v2, v0, v3, v5}, Linstafel/app/utils/localization/LocalizedStringGetter;->getDialogLocalizedString(Landroid/app/Activity;Ljava/util/Locale;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v11

    iget-object v2, v1, Linstafel/app/ota/tasks/BuildInfoTask;->act:Landroid/app/Activity;

    const-string v3, "ifl_d1_03"

    new-array v4, v4, [Ljava/lang/Object;

    invoke-static {v2, v0, v3, v4}, Linstafel/app/utils/localization/LocalizedStringGetter;->getDialogLocalizedString(Landroid/app/Activity;Ljava/util/Locale;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v12

    new-instance v13, Linstafel/app/ota/tasks/BuildInfoTask$1;

    invoke-direct {v13, v1, v8}, Linstafel/app/ota/tasks/BuildInfoTask$1;-><init>(Linstafel/app/ota/tasks/BuildInfoTask;Ljava/lang/String;)V

    new-instance v14, Linstafel/app/ota/tasks/BuildInfoTask$2;

    invoke-direct {v14, v1}, Linstafel/app/ota/tasks/BuildInfoTask$2;-><init>(Linstafel/app/ota/tasks/BuildInfoTask;)V

    invoke-virtual/range {v9 .. v14}, Linstafel/app/utils/dialog/InstafelDialog;->addPozitiveAndNegativeButton(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Landroid/view/View$OnClickListener;Landroid/view/View$OnClickListener;)V

    iget-object v0, v1, Linstafel/app/ota/tasks/BuildInfoTask;->instafelDialog:Linstafel/app/utils/dialog/InstafelDialog;

    const-string v2, "bottom_space"

    const/16 v3, 0x1b

    invoke-virtual {v0, v2, v3}, Linstafel/app/utils/dialog/InstafelDialog;->addSpace(Ljava/lang/String;I)V

    iget-object v0, v1, Linstafel/app/ota/tasks/BuildInfoTask;->instafelDialog:Linstafel/app/utils/dialog/InstafelDialog;

    invoke-virtual {v0}, Linstafel/app/utils/dialog/InstafelDialog;->show()V

    return-void

    :cond_4
    iget-boolean v0, v1, Linstafel/app/ota/tasks/BuildInfoTask;->checkType:Z

    if-eqz v0, :cond_5

    new-instance v0, Landroid/app/Dialog;

    iget-object v2, v1, Linstafel/app/ota/tasks/BuildInfoTask;->act:Landroid/app/Activity;

    invoke-direct {v0, v2}, Landroid/app/Dialog;-><init>(Landroid/content/Context;)V

    sget v2, Linstafel/app/R$layout;->ifl_dg_ota_uptodate:I

    invoke-virtual {v0, v2}, Landroid/app/Dialog;->setContentView(I)V

    invoke-virtual {v0}, Landroid/app/Dialog;->getWindow()Landroid/view/Window;

    move-result-object v2

    const/4 v3, -0x2

    invoke-virtual {v2, v3, v3}, Landroid/view/Window;->setLayout(II)V

    invoke-virtual {v0}, Landroid/app/Dialog;->getWindow()Landroid/view/Window;

    move-result-object v2

    iget-object v3, v1, Linstafel/app/ota/tasks/BuildInfoTask;->act:Landroid/app/Activity;

    sget v5, Linstafel/app/R$drawable;->ifl_dg_ota_background:I

    invoke-virtual {v3, v5}, Landroid/app/Activity;->getDrawable(I)Landroid/graphics/drawable/Drawable;

    move-result-object v3

    invoke-virtual {v2, v3}, Landroid/view/Window;->setBackgroundDrawable(Landroid/graphics/drawable/Drawable;)V

    invoke-virtual {v0, v4}, Landroid/app/Dialog;->setCancelable(Z)V

    sget v2, Linstafel/app/R$id;->ifl_dg_button_okay:I

    invoke-virtual {v0, v2}, Landroid/app/Dialog;->findViewById(I)Landroid/view/View;

    move-result-object v2

    check-cast v2, Landroid/widget/LinearLayout;

    new-instance v3, Linstafel/app/ota/tasks/BuildInfoTask$3;

    invoke-direct {v3, v1, v0}, Linstafel/app/ota/tasks/BuildInfoTask$3;-><init>(Linstafel/app/ota/tasks/BuildInfoTask;Landroid/app/Dialog;)V

    invoke-virtual {v2, v3}, Landroid/widget/LinearLayout;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    invoke-virtual {v0}, Landroid/app/Dialog;->show()V
    :try_end_1
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_0

    :cond_5
    return-void

    :catch_0
    move-exception v0

    invoke-virtual {v0}, Ljava/lang/Exception;->printStackTrace()V

    return-void
.end method
