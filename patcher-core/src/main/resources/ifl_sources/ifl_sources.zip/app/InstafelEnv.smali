.class public Linstafel/app/InstafelEnv;
.super Ljava/lang/Object;
.source "InstafelEnv.java"


# static fields
.field public static APPLIED_PATCHES:Ljava/lang/String; = "_patchesjson_"

.field public static BRANCH:Ljava/lang/String; = "_branch_"

.field public static COMMIT:Ljava/lang/String; = "_commit_"

.field public static GENERATION_ID:Ljava/lang/String; = "_genid_"

.field public static IFL_LANG:Ljava/util/Locale; = null

.field public static IFL_THEME:I = 0x6523

.field public static IFL_VERSION:Ljava/lang/String; = "_iflver_"

.field public static IG_VERSION:Ljava/lang/String; = "_igver_"

.field public static IG_VERSION_CODE:Ljava/lang/String; = "_igvercode_"

.field public static PATCHER_TAG:Ljava/lang/String; = "_ptag"

.field public static PATCHER_VERSION:Ljava/lang/String; = "_pversion_"

.field public static PRODUCTION_MODE:Z = true


# direct methods
.method static constructor <clinit>()V
    .locals 0

    return-void
.end method

.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public static getSupportedLocaleList()Landroid/os/LocaleList;
    .locals 9

    const/16 v0, 0x13

    new-array v1, v0, [Ljava/lang/String;

    const-string v2, "en-US"

    const/4 v3, 0x0

    aput-object v2, v1, v3

    const-string v2, "ar-SA"

    const/4 v4, 0x1

    aput-object v2, v1, v4

    const/4 v2, 0x2

    const-string v5, "az-AZ"

    aput-object v5, v1, v2

    const/4 v2, 0x3

    const-string v5, "de-DE"

    aput-object v5, v1, v2

    const/4 v2, 0x4

    const-string v5, "el-GR"

    aput-object v5, v1, v2

    const/4 v2, 0x5

    const-string v5, "es-ES"

    aput-object v5, v1, v2

    const/4 v2, 0x6

    const-string v5, "fr-FR"

    aput-object v5, v1, v2

    const/4 v2, 0x7

    const-string v5, "hi-IN"

    aput-object v5, v1, v2

    const/16 v2, 0x8

    const-string v5, "hu-HU"

    aput-object v5, v1, v2

    const/16 v2, 0x9

    const-string v5, "in-ID"

    aput-object v5, v1, v2

    const/16 v2, 0xa

    const-string v5, "it-IT"

    aput-object v5, v1, v2

    const/16 v2, 0xb

    const-string v5, "pl-PL"

    aput-object v5, v1, v2

    const/16 v2, 0xc

    const-string v5, "pt-BR"

    aput-object v5, v1, v2

    const/16 v2, 0xd

    const-string v5, "sr-CS"

    aput-object v5, v1, v2

    const/16 v2, 0xe

    const-string v5, "th-TH"

    aput-object v5, v1, v2

    const/16 v2, 0xf

    const-string v5, "tr-TR"

    aput-object v5, v1, v2

    const/16 v2, 0x10

    const-string v5, "zh-CN"

    aput-object v5, v1, v2

    const/16 v2, 0x11

    const-string v5, "zh-HK"

    aput-object v5, v1, v2

    const/16 v2, 0x12

    const-string v5, "zh-TW"

    aput-object v5, v1, v2

    new-array v2, v0, [Ljava/util/Locale;

    move v5, v3

    :goto_0
    if-ge v5, v0, :cond_0

    aget-object v6, v1, v5

    const-string v7, "-"

    invoke-virtual {v6, v7}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v6

    aget-object v7, v6, v3

    aget-object v6, v6, v4

    new-instance v8, Ljava/util/Locale;

    invoke-direct {v8, v7, v6}, Ljava/util/Locale;-><init>(Ljava/lang/String;Ljava/lang/String;)V

    aput-object v8, v2, v5

    add-int/lit8 v5, v5, 0x1

    goto :goto_0

    :cond_0
    new-instance v0, Landroid/os/LocaleList;

    invoke-direct {v0, v2}, Landroid/os/LocaleList;-><init>([Ljava/util/Locale;)V

    return-object v0
.end method

.method public static isPatchApplied(Ljava/lang/String;)Z
    .locals 8

    const/4 v0, 0x0

    :try_start_0
    new-instance v1, Lorg/json/JSONObject;

    sget-object v2, Linstafel/app/InstafelEnv;->APPLIED_PATCHES:Ljava/lang/String;

    invoke-direct {v1, v2}, Lorg/json/JSONObject;-><init>(Ljava/lang/String;)V

    const-string v2, "singlePatches"

    invoke-virtual {v1, v2}, Lorg/json/JSONObject;->getJSONArray(Ljava/lang/String;)Lorg/json/JSONArray;

    move-result-object v2

    const-string v3, "groupPatches"

    invoke-virtual {v1, v3}, Lorg/json/JSONObject;->getJSONArray(Ljava/lang/String;)Lorg/json/JSONArray;

    move-result-object v1

    move v3, v0

    :goto_0
    invoke-virtual {v2}, Lorg/json/JSONArray;->length()I

    move-result v4
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    const-string v5, "shortname"

    const/4 v6, 0x1

    if-ge v3, v4, :cond_1

    :try_start_1
    invoke-virtual {v2, v3}, Lorg/json/JSONArray;->getJSONObject(I)Lorg/json/JSONObject;

    move-result-object v4

    invoke-virtual {v4, v5}, Lorg/json/JSONObject;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v4, p0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v4

    if-eqz v4, :cond_0

    return v6

    :cond_0
    add-int/lit8 v3, v3, 0x1

    goto :goto_0

    :cond_1
    move v2, v0

    :goto_1
    invoke-virtual {v1}, Lorg/json/JSONArray;->length()I

    move-result v3

    if-ge v2, v3, :cond_4

    invoke-virtual {v1, v2}, Lorg/json/JSONArray;->getJSONObject(I)Lorg/json/JSONObject;

    move-result-object v3

    const-string v4, "patches"

    invoke-virtual {v3, v4}, Lorg/json/JSONObject;->getJSONArray(Ljava/lang/String;)Lorg/json/JSONArray;

    move-result-object v3

    move v4, v0

    :goto_2
    invoke-virtual {v3}, Lorg/json/JSONArray;->length()I

    move-result v7

    if-ge v4, v7, :cond_3

    invoke-virtual {v3, v4}, Lorg/json/JSONArray;->getJSONObject(I)Lorg/json/JSONObject;

    move-result-object v7

    invoke-virtual {v7, v5}, Lorg/json/JSONObject;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v7

    invoke-virtual {v7, p0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v7
    :try_end_1
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_0

    if-eqz v7, :cond_2

    return v6

    :cond_2
    add-int/lit8 v4, v4, 0x1

    goto :goto_2

    :cond_3
    add-int/lit8 v2, v2, 0x1

    goto :goto_1

    :catch_0
    :cond_4
    return v0
.end method
