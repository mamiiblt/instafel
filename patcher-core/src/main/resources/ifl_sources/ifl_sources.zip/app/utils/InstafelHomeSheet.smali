.class public Linstafel/app/utils/InstafelHomeSheet;
.super Ljava/lang/Object;
.source "InstafelHomeSheet.java"


# instance fields
.field private act:Landroid/app/Activity;

.field private iflLocale:Ljava/util/Locale;

.field private sheetDialog:Landroid/app/Dialog;

.field private sheetThemeMode:I


# direct methods
.method public constructor <init>(Landroid/app/Activity;)V
    .locals 1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v0, 0x0

    iput-object v0, p0, Linstafel/app/utils/InstafelHomeSheet;->sheetDialog:Landroid/app/Dialog;

    iput-object p1, p0, Linstafel/app/utils/InstafelHomeSheet;->act:Landroid/app/Activity;

    invoke-static {p1}, Linstafel/app/utils/GeneralFn;->getUiMode(Landroid/app/Activity;)I

    move-result v0

    iput v0, p0, Linstafel/app/utils/InstafelHomeSheet;->sheetThemeMode:I

    invoke-static {p1}, Linstafel/app/utils/localization/LocalizationUtils;->getIflLocale(Landroid/content/Context;)Ljava/util/Locale;

    move-result-object p1

    iput-object p1, p0, Linstafel/app/utils/InstafelHomeSheet;->iflLocale:Ljava/util/Locale;

    return-void
.end method

.method private buildSheet()V
    .locals 14

    new-instance v0, Landroid/app/Dialog;

    iget-object v1, p0, Linstafel/app/utils/InstafelHomeSheet;->act:Landroid/app/Activity;

    invoke-direct {v0, v1}, Landroid/app/Dialog;-><init>(Landroid/content/Context;)V

    const/4 v1, 0x1

    invoke-virtual {v0, v1}, Landroid/app/Dialog;->requestWindowFeature(I)Z

    invoke-virtual {v0, v1}, Landroid/app/Dialog;->setCancelable(Z)V

    new-instance v2, Landroid/widget/LinearLayout;

    iget-object v3, p0, Linstafel/app/utils/InstafelHomeSheet;->act:Landroid/app/Activity;

    invoke-direct {v2, v3}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    invoke-virtual {v2, v1}, Landroid/widget/LinearLayout;->setOrientation(I)V

    const/16 v3, 0x10

    invoke-static {v3}, Linstafel/app/utils/InstafelHomeSheet;->dp(I)I

    move-result v4

    invoke-static {v3}, Linstafel/app/utils/InstafelHomeSheet;->dp(I)I

    move-result v5

    invoke-static {v3}, Linstafel/app/utils/InstafelHomeSheet;->dp(I)I

    move-result v6

    invoke-static {v3}, Linstafel/app/utils/InstafelHomeSheet;->dp(I)I

    move-result v3

    invoke-virtual {v2, v4, v5, v6, v3}, Landroid/widget/LinearLayout;->setPadding(IIII)V

    new-instance v3, Landroid/graphics/drawable/GradientDrawable;

    invoke-direct {v3}, Landroid/graphics/drawable/GradientDrawable;-><init>()V

    iget v4, p0, Linstafel/app/utils/InstafelHomeSheet;->sheetThemeMode:I

    if-eqz v4, :cond_1

    if-ne v4, v1, :cond_0

    goto :goto_0

    :cond_0
    iget-object v4, p0, Linstafel/app/utils/InstafelHomeSheet;->act:Landroid/app/Activity;

    invoke-virtual {v4}, Landroid/app/Activity;->getResources()Landroid/content/res/Resources;

    move-result-object v4

    sget v5, Linstafel/app/R$color;->ifl_sheet_background_light:I

    invoke-virtual {v4, v5}, Landroid/content/res/Resources;->getColor(I)I

    move-result v4

    invoke-virtual {v3, v4}, Landroid/graphics/drawable/GradientDrawable;->setColor(I)V

    goto :goto_1

    :cond_1
    :goto_0
    iget-object v4, p0, Linstafel/app/utils/InstafelHomeSheet;->act:Landroid/app/Activity;

    invoke-virtual {v4}, Landroid/app/Activity;->getResources()Landroid/content/res/Resources;

    move-result-object v4

    sget v5, Linstafel/app/R$color;->ifl_sheet_background_dark:I

    invoke-virtual {v4, v5}, Landroid/content/res/Resources;->getColor(I)I

    move-result v4

    invoke-virtual {v3, v4}, Landroid/graphics/drawable/GradientDrawable;->setColor(I)V

    :goto_1
    const/16 v4, 0x1c

    invoke-static {v4}, Linstafel/app/utils/InstafelHomeSheet;->dp(I)I

    move-result v5

    int-to-float v5, v5

    invoke-static {v4}, Linstafel/app/utils/InstafelHomeSheet;->dp(I)I

    move-result v6

    int-to-float v6, v6

    invoke-static {v4}, Linstafel/app/utils/InstafelHomeSheet;->dp(I)I

    move-result v7

    int-to-float v7, v7

    invoke-static {v4}, Linstafel/app/utils/InstafelHomeSheet;->dp(I)I

    move-result v8

    int-to-float v8, v8

    invoke-static {v4}, Linstafel/app/utils/InstafelHomeSheet;->dp(I)I

    move-result v9

    int-to-float v9, v9

    invoke-static {v4}, Linstafel/app/utils/InstafelHomeSheet;->dp(I)I

    move-result v10

    int-to-float v10, v10

    invoke-static {v4}, Linstafel/app/utils/InstafelHomeSheet;->dp(I)I

    move-result v11

    int-to-float v11, v11

    invoke-static {v4}, Linstafel/app/utils/InstafelHomeSheet;->dp(I)I

    move-result v4

    int-to-float v4, v4

    const/16 v12, 0x8

    new-array v12, v12, [F

    const/4 v13, 0x0

    aput v5, v12, v13

    aput v6, v12, v1

    const/4 v1, 0x2

    aput v7, v12, v1

    const/4 v1, 0x3

    aput v8, v12, v1

    const/4 v1, 0x4

    aput v9, v12, v1

    const/4 v1, 0x5

    aput v10, v12, v1

    const/4 v1, 0x6

    aput v11, v12, v1

    const/4 v1, 0x7

    aput v4, v12, v1

    invoke-virtual {v3, v12}, Landroid/graphics/drawable/GradientDrawable;->setCornerRadii([F)V

    invoke-virtual {v2, v3}, Landroid/widget/LinearLayout;->setBackground(Landroid/graphics/drawable/Drawable;)V

    invoke-direct {p0}, Linstafel/app/utils/InstafelHomeSheet;->buildSheetContent()Landroid/widget/LinearLayout;

    move-result-object v1

    invoke-virtual {v2, v1}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    invoke-virtual {v0, v2}, Landroid/app/Dialog;->setContentView(Landroid/view/View;)V

    invoke-virtual {v0}, Landroid/app/Dialog;->getWindow()Landroid/view/Window;

    move-result-object v1

    if-eqz v1, :cond_2

    const/4 v2, -0x1

    const/4 v3, -0x2

    invoke-virtual {v1, v2, v3}, Landroid/view/Window;->setLayout(II)V

    const/16 v2, 0x50

    invoke-virtual {v1, v2}, Landroid/view/Window;->setGravity(I)V

    new-instance v2, Landroid/graphics/drawable/ColorDrawable;

    invoke-direct {v2, v13}, Landroid/graphics/drawable/ColorDrawable;-><init>(I)V

    invoke-virtual {v1, v2}, Landroid/view/Window;->setBackgroundDrawable(Landroid/graphics/drawable/Drawable;)V

    const v2, 0x1030002

    invoke-virtual {v1, v2}, Landroid/view/Window;->setWindowAnimations(I)V

    :cond_2
    iput-object v0, p0, Linstafel/app/utils/InstafelHomeSheet;->sheetDialog:Landroid/app/Dialog;

    return-void
.end method

.method private buildSheetContent()Landroid/widget/LinearLayout;
    .locals 14

    iget v0, p0, Linstafel/app/utils/InstafelHomeSheet;->sheetThemeMode:I

    const/4 v1, 0x1

    if-eqz v0, :cond_1

    if-ne v0, v1, :cond_0

    goto :goto_0

    :cond_0
    iget-object v0, p0, Linstafel/app/utils/InstafelHomeSheet;->act:Landroid/app/Activity;

    invoke-virtual {v0}, Landroid/app/Activity;->getResources()Landroid/content/res/Resources;

    move-result-object v0

    sget v2, Linstafel/app/R$color;->ifl_sheet_background_light:I

    invoke-virtual {v0, v2}, Landroid/content/res/Resources;->getColor(I)I

    move-result v0

    iget-object v2, p0, Linstafel/app/utils/InstafelHomeSheet;->act:Landroid/app/Activity;

    invoke-virtual {v2}, Landroid/app/Activity;->getResources()Landroid/content/res/Resources;

    move-result-object v2

    sget v3, Linstafel/app/R$color;->ifl_sheet_text_main_light:I

    invoke-virtual {v2, v3}, Landroid/content/res/Resources;->getColor(I)I

    move-result v2

    iget-object v3, p0, Linstafel/app/utils/InstafelHomeSheet;->act:Landroid/app/Activity;

    invoke-virtual {v3}, Landroid/app/Activity;->getResources()Landroid/content/res/Resources;

    move-result-object v3

    sget v4, Linstafel/app/R$color;->ifl_sheet_text_sub_light:I

    invoke-virtual {v3, v4}, Landroid/content/res/Resources;->getColor(I)I

    move-result v3

    goto :goto_1

    :cond_1
    :goto_0
    iget-object v0, p0, Linstafel/app/utils/InstafelHomeSheet;->act:Landroid/app/Activity;

    invoke-virtual {v0}, Landroid/app/Activity;->getResources()Landroid/content/res/Resources;

    move-result-object v0

    sget v2, Linstafel/app/R$color;->ifl_sheet_background_dark:I

    invoke-virtual {v0, v2}, Landroid/content/res/Resources;->getColor(I)I

    move-result v0

    iget-object v2, p0, Linstafel/app/utils/InstafelHomeSheet;->act:Landroid/app/Activity;

    invoke-virtual {v2}, Landroid/app/Activity;->getResources()Landroid/content/res/Resources;

    move-result-object v2

    sget v3, Linstafel/app/R$color;->ifl_sheet_text_main_dark:I

    invoke-virtual {v2, v3}, Landroid/content/res/Resources;->getColor(I)I

    move-result v2

    iget-object v3, p0, Linstafel/app/utils/InstafelHomeSheet;->act:Landroid/app/Activity;

    invoke-virtual {v3}, Landroid/app/Activity;->getResources()Landroid/content/res/Resources;

    move-result-object v3

    sget v4, Linstafel/app/R$color;->ifl_sheet_text_sub_dark:I

    invoke-virtual {v3, v4}, Landroid/content/res/Resources;->getColor(I)I

    move-result v3

    :goto_1
    new-instance v4, Landroid/widget/LinearLayout;

    iget-object v5, p0, Linstafel/app/utils/InstafelHomeSheet;->act:Landroid/app/Activity;

    invoke-direct {v4, v5}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    invoke-virtual {v4, v1}, Landroid/widget/LinearLayout;->setOrientation(I)V

    new-instance v5, Landroid/widget/LinearLayout$LayoutParams;

    const/4 v6, -0x1

    invoke-direct {v5, v6, v6}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    invoke-virtual {v4, v5}, Landroid/widget/LinearLayout;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    invoke-virtual {v4, v0}, Landroid/widget/LinearLayout;->setBackgroundColor(I)V

    new-instance v0, Landroid/widget/LinearLayout;

    iget-object v5, p0, Linstafel/app/utils/InstafelHomeSheet;->act:Landroid/app/Activity;

    invoke-direct {v0, v5}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    const/4 v5, 0x0

    invoke-virtual {v0, v5}, Landroid/widget/LinearLayout;->setOrientation(I)V

    const/16 v7, 0x10

    invoke-virtual {v0, v7}, Landroid/widget/LinearLayout;->setGravity(I)V

    const/16 v7, 0xf

    invoke-static {v7}, Linstafel/app/utils/InstafelHomeSheet;->dp(I)I

    move-result v8

    invoke-static {v7}, Linstafel/app/utils/InstafelHomeSheet;->dp(I)I

    move-result v9

    invoke-static {v7}, Linstafel/app/utils/InstafelHomeSheet;->dp(I)I

    move-result v10

    invoke-static {v7}, Linstafel/app/utils/InstafelHomeSheet;->dp(I)I

    move-result v11

    invoke-virtual {v0, v8, v9, v10, v11}, Landroid/widget/LinearLayout;->setPadding(IIII)V

    new-instance v8, Landroid/widget/LinearLayout$LayoutParams;

    const/4 v9, -0x2

    invoke-direct {v8, v6, v9}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    invoke-virtual {v0, v8}, Landroid/widget/LinearLayout;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    new-instance v6, Landroid/widget/ImageView;

    iget-object v8, p0, Linstafel/app/utils/InstafelHomeSheet;->act:Landroid/app/Activity;

    invoke-direct {v6, v8}, Landroid/widget/ImageView;-><init>(Landroid/content/Context;)V

    new-instance v8, Landroid/widget/LinearLayout$LayoutParams;

    const/16 v10, 0x31

    invoke-static {v10}, Linstafel/app/utils/InstafelHomeSheet;->dp(I)I

    move-result v11

    invoke-static {v10}, Linstafel/app/utils/InstafelHomeSheet;->dp(I)I

    move-result v10

    invoke-direct {v8, v11, v10}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    invoke-virtual {v6, v8}, Landroid/widget/ImageView;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    sget v8, Linstafel/app/R$drawable;->ifl_instafel:I

    invoke-virtual {v6, v8}, Landroid/widget/ImageView;->setImageResource(I)V

    invoke-virtual {v6, v2}, Landroid/widget/ImageView;->setColorFilter(I)V

    sget-object v8, Landroid/widget/ImageView$ScaleType;->FIT_CENTER:Landroid/widget/ImageView$ScaleType;

    invoke-virtual {v6, v8}, Landroid/widget/ImageView;->setScaleType(Landroid/widget/ImageView$ScaleType;)V

    new-instance v8, Landroid/view/View;

    iget-object v10, p0, Linstafel/app/utils/InstafelHomeSheet;->act:Landroid/app/Activity;

    invoke-direct {v8, v10}, Landroid/view/View;-><init>(Landroid/content/Context;)V

    new-instance v10, Landroid/widget/LinearLayout$LayoutParams;

    invoke-static {v7}, Linstafel/app/utils/InstafelHomeSheet;->dp(I)I

    move-result v7

    invoke-direct {v10, v7, v1}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    invoke-virtual {v8, v10}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    new-instance v7, Landroid/widget/LinearLayout;

    iget-object v10, p0, Linstafel/app/utils/InstafelHomeSheet;->act:Landroid/app/Activity;

    invoke-direct {v7, v10}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    invoke-virtual {v7, v1}, Landroid/widget/LinearLayout;->setOrientation(I)V

    new-instance v1, Landroid/widget/LinearLayout$LayoutParams;

    const/high16 v10, 0x3f800000    # 1.0f

    invoke-direct {v1, v5, v9, v10}, Landroid/widget/LinearLayout$LayoutParams;-><init>(IIF)V

    invoke-virtual {v7, v1}, Landroid/widget/LinearLayout;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    new-instance v1, Landroid/widget/TextView;

    iget-object v9, p0, Linstafel/app/utils/InstafelHomeSheet;->act:Landroid/app/Activity;

    invoke-direct {v1, v9}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V

    iget-object v9, p0, Linstafel/app/utils/InstafelHomeSheet;->act:Landroid/app/Activity;

    iget-object v10, p0, Linstafel/app/utils/InstafelHomeSheet;->iflLocale:Ljava/util/Locale;

    const-string v11, "ifl_d5_01"

    new-array v12, v5, [Ljava/lang/Object;

    invoke-static {v9, v10, v11, v12}, Linstafel/app/utils/localization/LocalizedStringGetter;->getDialogLocalizedString(Landroid/app/Activity;Ljava/util/Locale;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v9

    invoke-virtual {v1, v9}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    invoke-virtual {v1, v2}, Landroid/widget/TextView;->setTextColor(I)V

    const/high16 v9, 0x41a00000    # 20.0f

    invoke-virtual {v1, v9}, Landroid/widget/TextView;->setTextSize(F)V

    sget-object v9, Landroid/graphics/Typeface;->DEFAULT_BOLD:Landroid/graphics/Typeface;

    invoke-virtual {v1, v9}, Landroid/widget/TextView;->setTypeface(Landroid/graphics/Typeface;)V

    new-instance v9, Landroid/widget/TextView;

    iget-object v10, p0, Linstafel/app/utils/InstafelHomeSheet;->act:Landroid/app/Activity;

    invoke-direct {v9, v10}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V

    iget-object v10, p0, Linstafel/app/utils/InstafelHomeSheet;->act:Landroid/app/Activity;

    iget-object v11, p0, Linstafel/app/utils/InstafelHomeSheet;->iflLocale:Ljava/util/Locale;

    sget-object v12, Linstafel/app/InstafelEnv;->IFL_VERSION:Ljava/lang/String;

    sget-object v13, Linstafel/app/InstafelEnv;->IG_VERSION:Ljava/lang/String;

    filled-new-array {v12, v13}, [Ljava/lang/Object;

    move-result-object v12

    const-string v13, "ifl_d5_02"

    invoke-static {v10, v11, v13, v12}, Linstafel/app/utils/localization/LocalizedStringGetter;->getDialogLocalizedString(Landroid/app/Activity;Ljava/util/Locale;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v10

    invoke-virtual {v9, v10}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    invoke-virtual {v9, v3}, Landroid/widget/TextView;->setTextColor(I)V

    const/high16 v3, 0x41600000    # 14.0f

    invoke-virtual {v9, v3}, Landroid/widget/TextView;->setTextSize(F)V

    invoke-virtual {v7, v1}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    invoke-virtual {v7, v9}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    invoke-virtual {v0, v6}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    invoke-virtual {v0, v8}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    invoke-virtual {v0, v7}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    invoke-virtual {v4, v0}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    sget v0, Linstafel/app/R$drawable;->ifl_menu:I

    iget-object v1, p0, Linstafel/app/utils/InstafelHomeSheet;->act:Landroid/app/Activity;

    iget-object v3, p0, Linstafel/app/utils/InstafelHomeSheet;->iflLocale:Ljava/util/Locale;

    const-string v6, "ifl_d5_03"

    new-array v7, v5, [Ljava/lang/Object;

    invoke-static {v1, v3, v6, v7}, Linstafel/app/utils/localization/LocalizedStringGetter;->getDialogLocalizedString(Landroid/app/Activity;Ljava/util/Locale;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v1

    new-instance v3, Linstafel/app/utils/InstafelHomeSheet$$ExternalSyntheticLambda0;

    invoke-direct {v3, p0}, Linstafel/app/utils/InstafelHomeSheet$$ExternalSyntheticLambda0;-><init>(Linstafel/app/utils/InstafelHomeSheet;)V

    invoke-direct {p0, v0, v1, v2, v3}, Linstafel/app/utils/InstafelHomeSheet;->menuItem(ILjava/lang/String;ILandroid/view/View$OnClickListener;)Landroid/view/View;

    move-result-object v0

    invoke-virtual {v4, v0}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    sget v0, Linstafel/app/R$drawable;->ifl_metaoverrides:I

    iget-object v1, p0, Linstafel/app/utils/InstafelHomeSheet;->act:Landroid/app/Activity;

    iget-object v3, p0, Linstafel/app/utils/InstafelHomeSheet;->iflLocale:Ljava/util/Locale;

    const-string v6, "ifl_d5_04"

    new-array v7, v5, [Ljava/lang/Object;

    invoke-static {v1, v3, v6, v7}, Linstafel/app/utils/localization/LocalizedStringGetter;->getDialogLocalizedString(Landroid/app/Activity;Ljava/util/Locale;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v1

    new-instance v3, Linstafel/app/utils/InstafelHomeSheet$$ExternalSyntheticLambda1;

    invoke-direct {v3, p0}, Linstafel/app/utils/InstafelHomeSheet$$ExternalSyntheticLambda1;-><init>(Linstafel/app/utils/InstafelHomeSheet;)V

    invoke-direct {p0, v0, v1, v2, v3}, Linstafel/app/utils/InstafelHomeSheet;->menuItem(ILjava/lang/String;ILandroid/view/View$OnClickListener;)Landroid/view/View;

    move-result-object v0

    invoke-virtual {v4, v0}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    sget v0, Linstafel/app/R$drawable;->ifl_community_icon:I

    iget-object v1, p0, Linstafel/app/utils/InstafelHomeSheet;->act:Landroid/app/Activity;

    iget-object v3, p0, Linstafel/app/utils/InstafelHomeSheet;->iflLocale:Ljava/util/Locale;

    const-string v6, "ifl_d5_05"

    new-array v7, v5, [Ljava/lang/Object;

    invoke-static {v1, v3, v6, v7}, Linstafel/app/utils/localization/LocalizedStringGetter;->getDialogLocalizedString(Landroid/app/Activity;Ljava/util/Locale;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v1

    new-instance v3, Linstafel/app/utils/InstafelHomeSheet$$ExternalSyntheticLambda2;

    invoke-direct {v3, p0}, Linstafel/app/utils/InstafelHomeSheet$$ExternalSyntheticLambda2;-><init>(Linstafel/app/utils/InstafelHomeSheet;)V

    invoke-direct {p0, v0, v1, v2, v3}, Linstafel/app/utils/InstafelHomeSheet;->menuItem(ILjava/lang/String;ILandroid/view/View$OnClickListener;)Landroid/view/View;

    move-result-object v0

    invoke-virtual {v4, v0}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    sget v0, Linstafel/app/R$drawable;->ifl_sheet_reload:I

    iget-object v1, p0, Linstafel/app/utils/InstafelHomeSheet;->act:Landroid/app/Activity;

    iget-object v3, p0, Linstafel/app/utils/InstafelHomeSheet;->iflLocale:Ljava/util/Locale;

    const-string v6, "ifl_d5_06"

    new-array v5, v5, [Ljava/lang/Object;

    invoke-static {v1, v3, v6, v5}, Linstafel/app/utils/localization/LocalizedStringGetter;->getDialogLocalizedString(Landroid/app/Activity;Ljava/util/Locale;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v1

    new-instance v3, Linstafel/app/utils/InstafelHomeSheet$$ExternalSyntheticLambda3;

    invoke-direct {v3, p0}, Linstafel/app/utils/InstafelHomeSheet$$ExternalSyntheticLambda3;-><init>(Linstafel/app/utils/InstafelHomeSheet;)V

    invoke-direct {p0, v0, v1, v2, v3}, Linstafel/app/utils/InstafelHomeSheet;->menuItem(ILjava/lang/String;ILandroid/view/View$OnClickListener;)Landroid/view/View;

    move-result-object v0

    invoke-virtual {v4, v0}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    return-object v4
.end method

.method private static dp(I)I
    .locals 2

    int-to-float p0, p0

    invoke-static {}, Landroid/content/res/Resources;->getSystem()Landroid/content/res/Resources;

    move-result-object v0

    invoke-virtual {v0}, Landroid/content/res/Resources;->getDisplayMetrics()Landroid/util/DisplayMetrics;

    move-result-object v0

    const/4 v1, 0x1

    invoke-static {v1, p0, v0}, Landroid/util/TypedValue;->applyDimension(IFLandroid/util/DisplayMetrics;)F

    move-result p0

    float-to-int p0, p0

    return p0
.end method

.method private menuItem(ILjava/lang/String;ILandroid/view/View$OnClickListener;)Landroid/view/View;
    .locals 7

    new-instance v0, Landroid/widget/LinearLayout;

    iget-object v1, p0, Linstafel/app/utils/InstafelHomeSheet;->act:Landroid/app/Activity;

    invoke-direct {v0, v1}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    const/4 v1, 0x0

    invoke-virtual {v0, v1}, Landroid/widget/LinearLayout;->setOrientation(I)V

    const/16 v2, 0x10

    invoke-virtual {v0, v2}, Landroid/widget/LinearLayout;->setGravity(I)V

    const/16 v2, 0xf

    invoke-static {v2}, Linstafel/app/utils/InstafelHomeSheet;->dp(I)I

    move-result v3

    const/16 v4, 0xc

    invoke-static {v4}, Linstafel/app/utils/InstafelHomeSheet;->dp(I)I

    move-result v5

    invoke-static {v2}, Linstafel/app/utils/InstafelHomeSheet;->dp(I)I

    move-result v2

    invoke-static {v4}, Linstafel/app/utils/InstafelHomeSheet;->dp(I)I

    move-result v6

    invoke-virtual {v0, v3, v5, v2, v6}, Landroid/widget/LinearLayout;->setPadding(IIII)V

    const/4 v2, 0x1

    invoke-virtual {v0, v2}, Landroid/widget/LinearLayout;->setClickable(Z)V

    invoke-virtual {v0, v2}, Landroid/widget/LinearLayout;->setFocusable(Z)V

    invoke-virtual {v0, p4}, Landroid/widget/LinearLayout;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    new-instance p4, Landroid/widget/ImageView;

    iget-object v3, p0, Linstafel/app/utils/InstafelHomeSheet;->act:Landroid/app/Activity;

    invoke-direct {p4, v3}, Landroid/widget/ImageView;-><init>(Landroid/content/Context;)V

    invoke-virtual {p4, p1}, Landroid/widget/ImageView;->setImageResource(I)V

    invoke-virtual {p4, p3}, Landroid/widget/ImageView;->setColorFilter(I)V

    new-instance p1, Landroid/widget/LinearLayout$LayoutParams;

    const/16 v3, 0x18

    invoke-static {v3}, Linstafel/app/utils/InstafelHomeSheet;->dp(I)I

    move-result v5

    invoke-static {v3}, Linstafel/app/utils/InstafelHomeSheet;->dp(I)I

    move-result v3

    invoke-direct {p1, v5, v3}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    invoke-virtual {p4, p1}, Landroid/widget/ImageView;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    new-instance p1, Landroid/view/View;

    iget-object v3, p0, Linstafel/app/utils/InstafelHomeSheet;->act:Landroid/app/Activity;

    invoke-direct {p1, v3}, Landroid/view/View;-><init>(Landroid/content/Context;)V

    new-instance v3, Landroid/widget/LinearLayout$LayoutParams;

    invoke-static {v4}, Linstafel/app/utils/InstafelHomeSheet;->dp(I)I

    move-result v4

    invoke-direct {v3, v4, v2}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    invoke-virtual {p1, v3}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    new-instance v3, Landroid/widget/TextView;

    iget-object v4, p0, Linstafel/app/utils/InstafelHomeSheet;->act:Landroid/app/Activity;

    invoke-direct {v3, v4}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V

    invoke-virtual {v3, p2}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    const/high16 p2, 0x41800000    # 16.0f

    invoke-virtual {v3, p2}, Landroid/widget/TextView;->setTextSize(F)V

    invoke-virtual {v3, p3}, Landroid/widget/TextView;->setTextColor(I)V

    invoke-virtual {v3, v2}, Landroid/widget/TextView;->setMaxLines(I)V

    sget-object p2, Landroid/text/TextUtils$TruncateAt;->END:Landroid/text/TextUtils$TruncateAt;

    invoke-virtual {v3, p2}, Landroid/widget/TextView;->setEllipsize(Landroid/text/TextUtils$TruncateAt;)V

    new-instance p2, Landroid/widget/LinearLayout$LayoutParams;

    const/4 p3, -0x2

    const/high16 v2, 0x3f800000    # 1.0f

    invoke-direct {p2, v1, p3, v2}, Landroid/widget/LinearLayout$LayoutParams;-><init>(IIF)V

    invoke-virtual {v3, p2}, Landroid/widget/TextView;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    invoke-virtual {v0, p4}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    invoke-virtual {v0, p1}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    invoke-virtual {v0, v3}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    return-object v0
.end method


# virtual methods
.method public buildAndShowDialog()V
    .locals 3

    :try_start_0
    invoke-direct {p0}, Linstafel/app/utils/InstafelHomeSheet;->buildSheet()V

    iget-object v0, p0, Linstafel/app/utils/InstafelHomeSheet;->sheetDialog:Landroid/app/Dialog;

    invoke-virtual {v0}, Landroid/app/Dialog;->show()V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    return-void

    :catch_0
    iget-object v0, p0, Linstafel/app/utils/InstafelHomeSheet;->act:Landroid/app/Activity;

    const-string v1, "An error occurred while building / showing dialog"

    const/4 v2, 0x0

    invoke-static {v0, v1, v2}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object v0

    invoke-virtual {v0}, Landroid/widget/Toast;->show()V

    return-void
.end method

.method public dismissSheetDialog()V
    .locals 1

    iget-object v0, p0, Linstafel/app/utils/InstafelHomeSheet;->sheetDialog:Landroid/app/Dialog;

    invoke-virtual {v0}, Landroid/app/Dialog;->isShowing()Z

    move-result v0

    if-eqz v0, :cond_0

    iget-object v0, p0, Linstafel/app/utils/InstafelHomeSheet;->sheetDialog:Landroid/app/Dialog;

    invoke-virtual {v0}, Landroid/app/Dialog;->dismiss()V

    :cond_0
    return-void
.end method

.method synthetic lambda$buildSheetContent$0$instafel-app-utils-InstafelHomeSheet(Landroid/view/View;)V
    .locals 0

    invoke-virtual {p0}, Linstafel/app/utils/InstafelHomeSheet;->dismissSheetDialog()V

    invoke-static {}, Linstafel/app/utils/InitializeInstafel;->startInstafel()V

    return-void
.end method

.method synthetic lambda$buildSheetContent$1$instafel-app-utils-InstafelHomeSheet(Landroid/view/View;)V
    .locals 0

    invoke-virtual {p0}, Linstafel/app/utils/InstafelHomeSheet;->openDeveloperOptions()V

    return-void
.end method

.method synthetic lambda$buildSheetContent$2$instafel-app-utils-InstafelHomeSheet(Landroid/view/View;)V
    .locals 1

    iget-object p1, p0, Linstafel/app/utils/InstafelHomeSheet;->act:Landroid/app/Activity;

    const-string v0, "https://t.me/instafel"

    invoke-static {p1, v0}, Linstafel/app/utils/GeneralFn;->openInWebBrowser(Landroid/content/Context;Ljava/lang/String;)V

    return-void
.end method

.method synthetic lambda$buildSheetContent$3$instafel-app-utils-InstafelHomeSheet(Landroid/view/View;)V
    .locals 0

    invoke-virtual {p0}, Linstafel/app/utils/InstafelHomeSheet;->restartInstagram()V

    return-void
.end method

.method public openDeveloperOptions()V
    .locals 0

    return-void
.end method

.method public restartInstagram()V
    .locals 2

    iget-object v0, p0, Linstafel/app/utils/InstafelHomeSheet;->act:Landroid/app/Activity;

    invoke-virtual {v0}, Landroid/app/Activity;->getPackageManager()Landroid/content/pm/PackageManager;

    move-result-object v0

    iget-object v1, p0, Linstafel/app/utils/InstafelHomeSheet;->act:Landroid/app/Activity;

    invoke-virtual {v1}, Landroid/app/Activity;->getPackageName()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Landroid/content/pm/PackageManager;->getLaunchIntentForPackage(Ljava/lang/String;)Landroid/content/Intent;

    move-result-object v0

    const v1, 0x14008000

    invoke-virtual {v0, v1}, Landroid/content/Intent;->addFlags(I)Landroid/content/Intent;

    iget-object v1, p0, Linstafel/app/utils/InstafelHomeSheet;->act:Landroid/app/Activity;

    invoke-virtual {v1, v0}, Landroid/app/Activity;->startActivity(Landroid/content/Intent;)V

    invoke-static {}, Ljava/lang/Runtime;->getRuntime()Ljava/lang/Runtime;

    move-result-object v0

    const/4 v1, 0x0

    invoke-virtual {v0, v1}, Ljava/lang/Runtime;->exit(I)V

    return-void
.end method
