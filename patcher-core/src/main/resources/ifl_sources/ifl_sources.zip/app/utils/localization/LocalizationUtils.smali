.class public Linstafel/app/utils/localization/LocalizationUtils;
.super Ljava/lang/Object;
.source "LocalizationUtils.java"


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public static convertToLangCode(Ljava/util/Locale;)Ljava/lang/String;
    .locals 2

    invoke-virtual {p0}, Ljava/util/Locale;->getLanguage()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p0}, Ljava/util/Locale;->getCountry()Ljava/lang/String;

    move-result-object p0

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v1, "-"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object p0

    invoke-virtual {p0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    return-object p0
.end method

.method public static convertToLocale(Ljava/lang/String;)Ljava/util/Locale;
    .locals 2

    const-string v0, "-"

    invoke-virtual {p0, v0}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object p0

    const/4 v0, 0x0

    aget-object v0, p0, v0

    const/4 v1, 0x1

    aget-object p0, p0, v1

    new-instance v1, Ljava/util/Locale;

    invoke-direct {v1, v0, p0}, Ljava/util/Locale;-><init>(Ljava/lang/String;Ljava/lang/String;)V

    return-object v1
.end method

.method public static getActivityLocale(Landroid/content/Context;)Ljava/util/Locale;
    .locals 1

    invoke-virtual {p0}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object p0

    invoke-virtual {p0}, Landroid/content/res/Resources;->getConfiguration()Landroid/content/res/Configuration;

    move-result-object p0

    invoke-virtual {p0}, Landroid/content/res/Configuration;->getLocales()Landroid/os/LocaleList;

    move-result-object p0

    const/4 v0, 0x0

    invoke-virtual {p0, v0}, Landroid/os/LocaleList;->get(I)Ljava/util/Locale;

    move-result-object p0

    return-object p0
.end method

.method public static getDeviceLocale()Ljava/util/Locale;
    .locals 5

    invoke-static {}, Landroid/content/res/Resources;->getSystem()Landroid/content/res/Resources;

    move-result-object v0

    invoke-virtual {v0}, Landroid/content/res/Resources;->getConfiguration()Landroid/content/res/Configuration;

    move-result-object v0

    iget-object v0, v0, Landroid/content/res/Configuration;->locale:Ljava/util/Locale;

    const/4 v1, 0x0

    move v2, v1

    :goto_0
    invoke-static {}, Linstafel/app/InstafelEnv;->getSupportedLocaleList()Landroid/os/LocaleList;

    move-result-object v3

    invoke-virtual {v3}, Landroid/os/LocaleList;->size()I

    move-result v3

    if-ge v2, v3, :cond_1

    invoke-static {}, Linstafel/app/InstafelEnv;->getSupportedLocaleList()Landroid/os/LocaleList;

    move-result-object v3

    invoke-virtual {v3, v2}, Landroid/os/LocaleList;->get(I)Ljava/util/Locale;

    move-result-object v3

    invoke-virtual {v0, v3}, Ljava/util/Locale;->equals(Ljava/lang/Object;)Z

    move-result v4

    if-eqz v4, :cond_0

    return-object v3

    :cond_0
    add-int/lit8 v2, v2, 0x1

    goto :goto_0

    :cond_1
    invoke-static {}, Linstafel/app/InstafelEnv;->getSupportedLocaleList()Landroid/os/LocaleList;

    move-result-object v0

    invoke-virtual {v0, v1}, Landroid/os/LocaleList;->get(I)Ljava/util/Locale;

    move-result-object v0

    return-object v0
.end method

.method public static getIflLocale(Landroid/content/Context;)Ljava/util/Locale;
    .locals 2

    const-string v0, "def"

    :try_start_0
    new-instance v1, Linstafel/app/managers/PreferenceManager;

    invoke-direct {v1, p0}, Linstafel/app/managers/PreferenceManager;-><init>(Landroid/content/Context;)V

    sget-object p0, Linstafel/app/utils/types/PreferenceKeys;->ifl_lang_rw:Ljava/lang/String;

    invoke-virtual {v1, p0, v0}, Linstafel/app/managers/PreferenceManager;->getPreferenceString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    invoke-virtual {p0, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_0

    invoke-static {}, Linstafel/app/utils/localization/LocalizationUtils;->getDeviceLocale()Ljava/util/Locale;

    move-result-object p0

    return-object p0

    :cond_0
    invoke-static {p0}, Linstafel/app/utils/localization/LocalizationUtils;->convertToLocale(Ljava/lang/String;)Ljava/util/Locale;

    move-result-object p0
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    return-object p0

    :catch_0
    move-exception p0

    invoke-virtual {p0}, Ljava/lang/Exception;->printStackTrace()V

    invoke-static {}, Linstafel/app/InstafelEnv;->getSupportedLocaleList()Landroid/os/LocaleList;

    move-result-object p0

    const/4 v0, 0x0

    invoke-virtual {p0, v0}, Landroid/os/LocaleList;->get(I)Ljava/util/Locale;

    move-result-object p0

    return-object p0
.end method

.method static synthetic lambda$setLanguageClickListeners$0(Landroid/app/Activity;Ljava/util/Map$Entry;Ljava/util/Map;Landroid/view/View;)V
    .locals 0

    invoke-interface {p1}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    move-result-object p3

    check-cast p3, Ljava/util/Locale;

    invoke-static {p3}, Linstafel/app/utils/localization/LocalizationUtils;->convertToLangCode(Ljava/util/Locale;)Ljava/lang/String;

    move-result-object p3

    invoke-static {p0, p3}, Linstafel/app/utils/localization/LocalizationUtils;->writeLangToSP(Landroid/content/Context;Ljava/lang/String;)V

    invoke-interface {p1}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Ljava/util/Locale;

    invoke-static {p1}, Linstafel/app/utils/localization/LocalizationUtils;->convertToLangCode(Ljava/util/Locale;)Ljava/lang/String;

    move-result-object p1

    const/4 p3, 0x1

    invoke-static {p1, p3, p2}, Linstafel/app/utils/localization/LocalizationUtils;->setSubIconVisibilityOfLocale(Ljava/lang/String;ZLjava/util/Map;)V

    invoke-virtual {p0}, Landroid/app/Activity;->recreate()V

    return-void
.end method

.method public static setLanguageClickListeners(Landroid/app/Activity;Ljava/util/Map;)V
    .locals 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/app/Activity;",
            "Ljava/util/Map<",
            "Ljava/util/Locale;",
            "Linstafel/app/utils/localization/LocaleInfoTile;",
            ">;)V"
        }
    .end annotation

    invoke-interface {p1}, Ljava/util/Map;->entrySet()Ljava/util/Set;

    move-result-object v0

    invoke-interface {v0}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :goto_0
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_0

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/util/Map$Entry;

    invoke-interface {v1}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Linstafel/app/utils/localization/LocaleInfoTile;

    iget-object v2, v2, Linstafel/app/utils/localization/LocaleInfoTile;->localeTile:Linstafel/app/ui/TileLarge;

    new-instance v3, Linstafel/app/utils/localization/LocalizationUtils$$ExternalSyntheticLambda0;

    invoke-direct {v3, p0, v1, p1}, Linstafel/app/utils/localization/LocalizationUtils$$ExternalSyntheticLambda0;-><init>(Landroid/app/Activity;Ljava/util/Map$Entry;Ljava/util/Map;)V

    invoke-virtual {v2, v3}, Linstafel/app/ui/TileLarge;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    goto :goto_0

    :cond_0
    return-void
.end method

.method public static setLocale(Landroid/app/Activity;Ljava/util/Locale;)V
    .locals 2

    :try_start_0
    invoke-static {p1}, Ljava/util/Locale;->setDefault(Ljava/util/Locale;)V

    invoke-virtual {p0}, Landroid/app/Activity;->getResources()Landroid/content/res/Resources;

    move-result-object v0

    invoke-virtual {v0}, Landroid/content/res/Resources;->getConfiguration()Landroid/content/res/Configuration;

    move-result-object v1

    invoke-virtual {v1, p1}, Landroid/content/res/Configuration;->setLocale(Ljava/util/Locale;)V

    invoke-virtual {v0}, Landroid/content/res/Resources;->getDisplayMetrics()Landroid/util/DisplayMetrics;

    move-result-object p1

    invoke-virtual {v0, v1, p1}, Landroid/content/res/Resources;->updateConfiguration(Landroid/content/res/Configuration;Landroid/util/DisplayMetrics;)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    return-void

    :catch_0
    move-exception p1

    new-instance v0, Ljava/lang/StringBuilder;

    const-string v1, "Error while setting locale: "

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    move-result-object p1

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v0, 0x0

    invoke-static {p0, p1, v0}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object p0

    invoke-virtual {p0}, Landroid/widget/Toast;->show()V

    return-void
.end method

.method public static setStateOfDevice(Landroid/app/Activity;Z)V
    .locals 0

    if-eqz p1, :cond_0

    const-string p1, "def"

    goto :goto_0

    :cond_0
    invoke-static {}, Linstafel/app/utils/localization/LocalizationUtils;->getDeviceLocale()Ljava/util/Locale;

    move-result-object p1

    invoke-static {p1}, Linstafel/app/utils/localization/LocalizationUtils;->convertToLangCode(Ljava/util/Locale;)Ljava/lang/String;

    move-result-object p1

    :goto_0
    invoke-static {p0, p1}, Linstafel/app/utils/localization/LocalizationUtils;->writeLangToSP(Landroid/content/Context;Ljava/lang/String;)V

    invoke-virtual {p0}, Landroid/app/Activity;->recreate()V

    return-void
.end method

.method public static setSubIconVisibilityOfLocale(Ljava/lang/String;ZLjava/util/Map;)V
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Z",
            "Ljava/util/Map<",
            "Ljava/util/Locale;",
            "Linstafel/app/utils/localization/LocaleInfoTile;",
            ">;)V"
        }
    .end annotation

    invoke-interface {p2}, Ljava/util/Map;->entrySet()Ljava/util/Set;

    move-result-object p2

    invoke-interface {p2}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object p2

    :goto_0
    invoke-interface {p2}, Ljava/util/Iterator;->hasNext()Z

    move-result v0

    if-eqz v0, :cond_1

    invoke-interface {p2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/util/Map$Entry;

    invoke-interface {v0}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/util/Locale;

    invoke-static {v1}, Linstafel/app/utils/localization/LocalizationUtils;->convertToLangCode(Ljava/util/Locale;)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v1, p0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_0

    invoke-interface {v0}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Linstafel/app/utils/localization/LocaleInfoTile;

    invoke-virtual {v0, p1}, Linstafel/app/utils/localization/LocaleInfoTile;->setTickStatus(Z)V

    goto :goto_0

    :cond_0
    invoke-interface {v0}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Linstafel/app/utils/localization/LocaleInfoTile;

    const/4 v1, 0x0

    invoke-virtual {v0, v1}, Linstafel/app/utils/localization/LocaleInfoTile;->setTickStatus(Z)V

    goto :goto_0

    :cond_1
    return-void
.end method

.method public static setVisibilityOfAllLocales(ZLjava/util/Map;)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(Z",
            "Ljava/util/Map<",
            "Ljava/util/Locale;",
            "Linstafel/app/utils/localization/LocaleInfoTile;",
            ">;)V"
        }
    .end annotation

    invoke-interface {p1}, Ljava/util/Map;->entrySet()Ljava/util/Set;

    move-result-object p1

    invoke-interface {p1}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object p1

    :goto_0
    invoke-interface {p1}, Ljava/util/Iterator;->hasNext()Z

    move-result v0

    if-eqz v0, :cond_0

    invoke-interface {p1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/util/Map$Entry;

    invoke-interface {v0}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Linstafel/app/utils/localization/LocaleInfoTile;

    invoke-virtual {v0, p0}, Linstafel/app/utils/localization/LocaleInfoTile;->setTileVisibility(Z)V

    goto :goto_0

    :cond_0
    return-void
.end method

.method public static updateIflLocale(Landroid/app/Activity;Ljava/lang/Boolean;)V
    .locals 1

    :try_start_0
    invoke-static {p0}, Linstafel/app/utils/localization/LocalizationUtils;->getIflLocale(Landroid/content/Context;)Ljava/util/Locale;

    move-result-object v0

    invoke-virtual {p1}, Ljava/lang/Boolean;->booleanValue()Z

    move-result p1

    if-eqz p1, :cond_0

    sput-object v0, Linstafel/app/InstafelEnv;->IFL_LANG:Ljava/util/Locale;

    invoke-static {p0, v0}, Linstafel/app/utils/localization/LocalizationUtils;->setLocale(Landroid/app/Activity;Ljava/util/Locale;)V

    return-void

    :cond_0
    invoke-static {p0, v0}, Linstafel/app/utils/localization/LocalizationUtils;->setLocale(Landroid/app/Activity;Ljava/util/Locale;)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    return-void

    :catch_0
    move-exception p0

    invoke-virtual {p0}, Ljava/lang/Exception;->printStackTrace()V

    return-void
.end method

.method public static writeLangToSP(Landroid/content/Context;Ljava/lang/String;)V
    .locals 1

    new-instance v0, Linstafel/app/managers/PreferenceManager;

    invoke-direct {v0, p0}, Linstafel/app/managers/PreferenceManager;-><init>(Landroid/content/Context;)V

    sget-object p0, Linstafel/app/utils/types/PreferenceKeys;->ifl_lang_rw:Ljava/lang/String;

    invoke-virtual {v0, p0, p1}, Linstafel/app/managers/PreferenceManager;->setPreferenceString(Ljava/lang/String;Ljava/lang/String;)V

    return-void
.end method
