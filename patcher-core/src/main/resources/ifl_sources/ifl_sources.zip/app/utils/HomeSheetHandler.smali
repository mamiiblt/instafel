.class public Linstafel/app/utils/HomeSheetHandler;
.super Ljava/lang/Object;
.source "HomeSheetHandler.java"

# interfaces
.implements Landroid/view/View$OnLongClickListener;


# instance fields
.field private mainAppActivity:Landroid/app/Activity;


# direct methods
.method public constructor <init>(Landroid/content/Context;)V
    .locals 1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    instance-of v0, p1, Landroid/app/Activity;

    if-eqz v0, :cond_0

    check-cast p1, Landroid/app/Activity;

    iput-object p1, p0, Linstafel/app/utils/HomeSheetHandler;->mainAppActivity:Landroid/app/Activity;

    return-void

    :cond_0
    const/4 p1, 0x0

    iput-object p1, p0, Linstafel/app/utils/HomeSheetHandler;->mainAppActivity:Landroid/app/Activity;

    return-void
.end method


# virtual methods
.method public onLongClick(Landroid/view/View;)Z
    .locals 1

    iget-object p1, p0, Linstafel/app/utils/HomeSheetHandler;->mainAppActivity:Landroid/app/Activity;

    if-nez p1, :cond_0

    const/4 p1, 0x0

    return p1

    :cond_0
    new-instance p1, Linstafel/app/utils/InstafelHomeSheet;

    iget-object v0, p0, Linstafel/app/utils/HomeSheetHandler;->mainAppActivity:Landroid/app/Activity;

    invoke-direct {p1, v0}, Linstafel/app/utils/InstafelHomeSheet;-><init>(Landroid/app/Activity;)V

    invoke-virtual {p1}, Linstafel/app/utils/InstafelHomeSheet;->buildAndShowDialog()V

    const/4 p1, 0x1

    return p1
.end method
