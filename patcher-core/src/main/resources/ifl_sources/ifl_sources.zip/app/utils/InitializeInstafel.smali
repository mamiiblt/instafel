.class public Linstafel/app/utils/InitializeInstafel;
.super Ljava/lang/Object;
.source "InitializeInstafel.java"


# static fields
.field public static ctx:Landroid/content/Context;


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public static setContext(Landroid/app/Application;)V
    .locals 2

    sput-object p0, Linstafel/app/utils/InitializeInstafel;->ctx:Landroid/content/Context;

    invoke-static {p0}, Linstafel/app/utils/localization/LocalizationUtils;->getIflLocale(Landroid/content/Context;)Ljava/util/Locale;

    move-result-object p0

    sput-object p0, Linstafel/app/InstafelEnv;->IFL_LANG:Ljava/util/Locale;

    new-instance v0, Ljava/lang/StringBuilder;

    const-string v1, "InstafelEnv.IFL_LANG is set to "

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-static {p0}, Linstafel/app/utils/localization/LocalizationUtils;->convertToLangCode(Ljava/util/Locale;)Ljava/lang/String;

    move-result-object p0

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object p0

    invoke-virtual {p0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    const-string v0, "IFL"

    invoke-static {v0, p0}, Landroid/util/Log;->v(Ljava/lang/String;Ljava/lang/String;)I

    return-void
.end method

.method public static startInstafel()V
    .locals 3

    new-instance v0, Landroid/content/Intent;

    sget-object v1, Linstafel/app/utils/InitializeInstafel;->ctx:Landroid/content/Context;

    const-class v2, Linstafel/app/activity/ifl_a_menu;

    invoke-direct {v0, v1, v2}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    const/high16 v1, 0x10000000

    invoke-virtual {v0, v1}, Landroid/content/Intent;->addFlags(I)Landroid/content/Intent;

    sget-object v1, Linstafel/app/utils/InitializeInstafel;->ctx:Landroid/content/Context;

    invoke-virtual {v1, v0}, Landroid/content/Context;->startActivity(Landroid/content/Intent;)V

    return-void
.end method

.method public static triggerCheckUpdates(Landroid/app/Activity;)V
    .locals 0

    invoke-static {p0}, Linstafel/app/ota/CheckUpdates;->checkUpdates(Landroid/app/Activity;)V

    return-void
.end method

.method public static triggerUploadMapping(Landroid/app/Activity;)V
    .locals 2

    new-instance v0, Linstafel/app/managers/OverridesManager;

    invoke-direct {v0, p0}, Linstafel/app/managers/OverridesManager;-><init>(Landroid/app/Activity;)V

    invoke-static {p0}, Linstafel/app/utils/InstafelAdminUser;->isUserLogged(Landroid/app/Activity;)Z

    move-result v1

    if-eqz v1, :cond_0

    invoke-virtual {v0}, Linstafel/app/managers/OverridesManager;->getMappingFile()Ljava/io/File;

    move-result-object v0

    invoke-virtual {v0}, Ljava/io/File;->exists()Z

    move-result v0

    if-eqz v0, :cond_0

    new-instance v0, Linstafel/app/utils/UploadMapping;

    invoke-direct {v0, p0}, Linstafel/app/utils/UploadMapping;-><init>(Landroid/app/Activity;)V

    :cond_0
    return-void
.end method
