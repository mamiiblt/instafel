.class public Linstafel/app/utils/crashlog/Crashlog;
.super Ljava/lang/Object;
.source "Crashlog.java"


# instance fields
.field private appData:Linstafel/app/utils/crashlog/CLogDataTypes$AppData;

.field private crashData:Linstafel/app/utils/crashlog/CLogDataTypes$CrashData;

.field private date:Ljava/lang/Object;

.field private deviceData:Linstafel/app/utils/crashlog/CLogDataTypes$DeviceData;


# direct methods
.method public constructor <init>(Linstafel/app/utils/crashlog/CLogDataTypes$AppData;Linstafel/app/utils/crashlog/CLogDataTypes$DeviceData;Linstafel/app/utils/crashlog/CLogDataTypes$CrashData;Ljava/lang/Object;)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Linstafel/app/utils/crashlog/Crashlog;->appData:Linstafel/app/utils/crashlog/CLogDataTypes$AppData;

    iput-object p2, p0, Linstafel/app/utils/crashlog/Crashlog;->deviceData:Linstafel/app/utils/crashlog/CLogDataTypes$DeviceData;

    iput-object p3, p0, Linstafel/app/utils/crashlog/Crashlog;->crashData:Linstafel/app/utils/crashlog/CLogDataTypes$CrashData;

    iput-object p4, p0, Linstafel/app/utils/crashlog/Crashlog;->date:Ljava/lang/Object;

    return-void
.end method


# virtual methods
.method public convertToString()Ljava/lang/String;
    .locals 4

    :try_start_0
    new-instance v0, Lorg/json/JSONObject;

    invoke-direct {v0}, Lorg/json/JSONObject;-><init>()V

    new-instance v1, Lorg/json/JSONObject;

    invoke-direct {v1}, Lorg/json/JSONObject;-><init>()V

    const-string v2, "ifl_ver"

    iget-object v3, p0, Linstafel/app/utils/crashlog/Crashlog;->appData:Linstafel/app/utils/crashlog/CLogDataTypes$AppData;

    invoke-virtual {v3}, Linstafel/app/utils/crashlog/CLogDataTypes$AppData;->getIfl_ver()Ljava/lang/Object;

    move-result-object v3

    invoke-virtual {v1, v2, v3}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const-string v2, "ig_ver"

    iget-object v3, p0, Linstafel/app/utils/crashlog/Crashlog;->appData:Linstafel/app/utils/crashlog/CLogDataTypes$AppData;

    invoke-virtual {v3}, Linstafel/app/utils/crashlog/CLogDataTypes$AppData;->getIg_ver()Ljava/lang/Object;

    move-result-object v3

    invoke-virtual {v1, v2, v3}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const-string v2, "ig_ver_code"

    iget-object v3, p0, Linstafel/app/utils/crashlog/Crashlog;->appData:Linstafel/app/utils/crashlog/CLogDataTypes$AppData;

    invoke-virtual {v3}, Linstafel/app/utils/crashlog/CLogDataTypes$AppData;->getIg_ver_code()Ljava/lang/Object;

    move-result-object v3

    invoke-virtual {v1, v2, v3}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const-string v2, "ig_itype"

    iget-object v3, p0, Linstafel/app/utils/crashlog/Crashlog;->appData:Linstafel/app/utils/crashlog/CLogDataTypes$AppData;

    invoke-virtual {v3}, Linstafel/app/utils/crashlog/CLogDataTypes$AppData;->getIg_itype()Ljava/lang/Object;

    move-result-object v3

    invoke-virtual {v1, v2, v3}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const-string v2, "appData"

    invoke-virtual {v0, v2, v1}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    new-instance v1, Lorg/json/JSONObject;

    invoke-direct {v1}, Lorg/json/JSONObject;-><init>()V

    const-string v2, "aver"

    iget-object v3, p0, Linstafel/app/utils/crashlog/Crashlog;->deviceData:Linstafel/app/utils/crashlog/CLogDataTypes$DeviceData;

    invoke-virtual {v3}, Linstafel/app/utils/crashlog/CLogDataTypes$DeviceData;->getAver()Ljava/lang/Object;

    move-result-object v3

    invoke-virtual {v1, v2, v3}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const-string v2, "sdk"

    iget-object v3, p0, Linstafel/app/utils/crashlog/Crashlog;->deviceData:Linstafel/app/utils/crashlog/CLogDataTypes$DeviceData;

    invoke-virtual {v3}, Linstafel/app/utils/crashlog/CLogDataTypes$DeviceData;->getSdk()Ljava/lang/Object;

    move-result-object v3

    invoke-virtual {v1, v2, v3}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const-string v2, "model"

    iget-object v3, p0, Linstafel/app/utils/crashlog/Crashlog;->deviceData:Linstafel/app/utils/crashlog/CLogDataTypes$DeviceData;

    invoke-virtual {v3}, Linstafel/app/utils/crashlog/CLogDataTypes$DeviceData;->getModel()Ljava/lang/Object;

    move-result-object v3

    invoke-virtual {v1, v2, v3}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const-string v2, "brand"

    iget-object v3, p0, Linstafel/app/utils/crashlog/Crashlog;->deviceData:Linstafel/app/utils/crashlog/CLogDataTypes$DeviceData;

    invoke-virtual {v3}, Linstafel/app/utils/crashlog/CLogDataTypes$DeviceData;->getBrand()Ljava/lang/Object;

    move-result-object v3

    invoke-virtual {v1, v2, v3}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const-string v2, "product"

    iget-object v3, p0, Linstafel/app/utils/crashlog/Crashlog;->deviceData:Linstafel/app/utils/crashlog/CLogDataTypes$DeviceData;

    invoke-virtual {v3}, Linstafel/app/utils/crashlog/CLogDataTypes$DeviceData;->getProduct()Ljava/lang/Object;

    move-result-object v3

    invoke-virtual {v1, v2, v3}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const-string v2, "deviceData"

    invoke-virtual {v0, v2, v1}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    new-instance v1, Lorg/json/JSONObject;

    invoke-direct {v1}, Lorg/json/JSONObject;-><init>()V

    const-string v2, "msg"

    iget-object v3, p0, Linstafel/app/utils/crashlog/Crashlog;->crashData:Linstafel/app/utils/crashlog/CLogDataTypes$CrashData;

    invoke-virtual {v3}, Linstafel/app/utils/crashlog/CLogDataTypes$CrashData;->getMsg()Ljava/lang/Object;

    move-result-object v3

    invoke-virtual {v1, v2, v3}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const-string v2, "trace"

    iget-object v3, p0, Linstafel/app/utils/crashlog/Crashlog;->crashData:Linstafel/app/utils/crashlog/CLogDataTypes$CrashData;

    invoke-virtual {v3}, Linstafel/app/utils/crashlog/CLogDataTypes$CrashData;->getTrace()Ljava/lang/Object;

    move-result-object v3

    invoke-virtual {v1, v2, v3}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const-string v2, "class"

    iget-object v3, p0, Linstafel/app/utils/crashlog/Crashlog;->crashData:Linstafel/app/utils/crashlog/CLogDataTypes$CrashData;

    invoke-virtual {v3}, Linstafel/app/utils/crashlog/CLogDataTypes$CrashData;->getClassName()Ljava/lang/Object;

    move-result-object v3

    invoke-virtual {v1, v2, v3}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const-string v2, "crashData"

    invoke-virtual {v0, v2, v1}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const-string v1, "date"

    iget-object v2, p0, Linstafel/app/utils/crashlog/Crashlog;->date:Ljava/lang/Object;

    invoke-virtual {v0, v1, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    invoke-virtual {v0}, Lorg/json/JSONObject;->toString()Ljava/lang/String;

    move-result-object v0
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    return-object v0

    :catch_0
    move-exception v0

    invoke-virtual {v0}, Ljava/lang/Exception;->printStackTrace()V

    const-string v0, "ERROR_WHILE_CONVERTING_CRASHLOG"

    return-object v0
.end method

.method public getAppData()Linstafel/app/utils/crashlog/CLogDataTypes$AppData;
    .locals 1

    iget-object v0, p0, Linstafel/app/utils/crashlog/Crashlog;->appData:Linstafel/app/utils/crashlog/CLogDataTypes$AppData;

    return-object v0
.end method

.method public getCrashData()Linstafel/app/utils/crashlog/CLogDataTypes$CrashData;
    .locals 1

    iget-object v0, p0, Linstafel/app/utils/crashlog/Crashlog;->crashData:Linstafel/app/utils/crashlog/CLogDataTypes$CrashData;

    return-object v0
.end method

.method public getDate()Ljava/lang/Object;
    .locals 1

    iget-object v0, p0, Linstafel/app/utils/crashlog/Crashlog;->date:Ljava/lang/Object;

    return-object v0
.end method

.method public getDeviceData()Linstafel/app/utils/crashlog/CLogDataTypes$DeviceData;
    .locals 1

    iget-object v0, p0, Linstafel/app/utils/crashlog/Crashlog;->deviceData:Linstafel/app/utils/crashlog/CLogDataTypes$DeviceData;

    return-object v0
.end method
