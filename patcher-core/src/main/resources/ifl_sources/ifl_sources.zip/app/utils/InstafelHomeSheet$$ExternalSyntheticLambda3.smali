.class public final synthetic Linstafel/app/utils/InstafelHomeSheet$$ExternalSyntheticLambda3;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Landroid/view/View$OnClickListener;


# instance fields
.field public final synthetic f$0:Linstafel/app/utils/InstafelHomeSheet;


# direct methods
.method public synthetic constructor <init>(Linstafel/app/utils/InstafelHomeSheet;)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Linstafel/app/utils/InstafelHomeSheet$$ExternalSyntheticLambda3;->f$0:Linstafel/app/utils/InstafelHomeSheet;

    return-void
.end method


# virtual methods
.method public final onClick(Landroid/view/View;)V
    .locals 1

    iget-object v0, p0, Linstafel/app/utils/InstafelHomeSheet$$ExternalSyntheticLambda3;->f$0:Linstafel/app/utils/InstafelHomeSheet;

    invoke-virtual {v0, p1}, Linstafel/app/utils/InstafelHomeSheet;->lambda$buildSheetContent$3$instafel-app-utils-InstafelHomeSheet(Landroid/view/View;)V

    return-void
.end method
