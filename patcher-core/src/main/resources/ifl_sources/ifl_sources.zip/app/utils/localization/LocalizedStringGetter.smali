.class public Linstafel/app/utils/localization/LocalizedStringGetter;
.super Ljava/lang/Object;
.source "LocalizedStringGetter.java"


# static fields
.field static final synthetic $assertionsDisabled:Z


# direct methods
.method static constructor <clinit>()V
    .locals 0

    return-void
.end method

.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public static varargs getDialogLocalizedString(Landroid/app/Activity;Ljava/util/Locale;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;
    .locals 3

    :try_start_0
    invoke-static {p0, p1}, Linstafel/app/utils/GeneralFn;->getAppResourcesWithConf(Landroid/app/Activity;Ljava/util/Locale;)Landroid/content/res/Resources;

    move-result-object p1

    array-length v0, p3
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    const-string v1, "\n"

    const-string v2, "\\n"

    if-eqz v0, :cond_0

    :try_start_1
    invoke-static {p0, p1, p2}, Linstafel/app/utils/GeneralFn;->getStringResId(Landroid/app/Activity;Landroid/content/res/Resources;Ljava/lang/String;)I

    move-result p0

    invoke-virtual {p1, p0, p3}, Landroid/content/res/Resources;->getString(I[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p0

    invoke-virtual {p0, v2, v1}, Ljava/lang/String;->replace(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;

    move-result-object p0

    return-object p0

    :cond_0
    invoke-static {p0, p1, p2}, Linstafel/app/utils/GeneralFn;->getStringResId(Landroid/app/Activity;Landroid/content/res/Resources;Ljava/lang/String;)I

    move-result p0

    invoke-virtual {p1, p0}, Landroid/content/res/Resources;->getString(I)Ljava/lang/String;

    move-result-object p0

    invoke-virtual {p0, v2, v1}, Ljava/lang/String;->replace(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;

    move-result-object p0
    :try_end_1
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_0

    return-object p0

    :catch_0
    move-exception p0

    invoke-virtual {p0}, Ljava/lang/Exception;->printStackTrace()V

    const/4 p0, 0x0

    return-object p0
.end method

.method public static varargs getLocalizedString(Landroid/app/Activity;Ljava/util/Locale;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;
    .locals 1

    :try_start_0
    invoke-static {p0, p1}, Linstafel/app/utils/GeneralFn;->getAppResourcesWithConf(Landroid/app/Activity;Ljava/util/Locale;)Landroid/content/res/Resources;

    move-result-object p1

    array-length v0, p3

    if-eqz v0, :cond_0

    invoke-static {p0, p1, p2}, Linstafel/app/utils/GeneralFn;->getStringResId(Landroid/app/Activity;Landroid/content/res/Resources;Ljava/lang/String;)I

    move-result p2

    invoke-virtual {p1, p2, p3}, Landroid/content/res/Resources;->getString(I[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p0

    return-object p0

    :cond_0
    invoke-static {p0, p1, p2}, Linstafel/app/utils/GeneralFn;->getStringResId(Landroid/app/Activity;Landroid/content/res/Resources;Ljava/lang/String;)I

    move-result p2

    invoke-virtual {p1, p2}, Landroid/content/res/Resources;->getString(I)Ljava/lang/String;

    move-result-object p0
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    return-object p0

    :catch_0
    move-exception p1

    invoke-virtual {p1}, Ljava/lang/Exception;->printStackTrace()V

    invoke-virtual {p1}, Ljava/lang/Exception;->getMessage()Ljava/lang/String;

    move-result-object p1

    const/4 p2, 0x1

    invoke-static {p0, p1, p2}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object p0

    invoke-virtual {p0}, Landroid/widget/Toast;->show()V

    const/4 p0, 0x0

    return-object p0
.end method

.method public static getString(Landroid/app/Activity;Ljava/lang/String;)Ljava/lang/String;
    .locals 1

    invoke-static {p0}, Linstafel/app/utils/GeneralFn;->getAppResources(Landroid/app/Activity;)Landroid/content/res/Resources;

    move-result-object v0

    invoke-static {p0, v0, p1}, Linstafel/app/utils/GeneralFn;->getStringResId(Landroid/app/Activity;Landroid/content/res/Resources;Ljava/lang/String;)I

    move-result p0

    invoke-virtual {v0, p0}, Landroid/content/res/Resources;->getString(I)Ljava/lang/String;

    move-result-object p0

    return-object p0
.end method
