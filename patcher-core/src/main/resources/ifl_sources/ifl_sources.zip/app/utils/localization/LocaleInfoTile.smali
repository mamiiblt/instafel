.class public Linstafel/app/utils/localization/LocaleInfoTile;
.super Ljava/lang/Object;
.source "LocaleInfoTile.java"


# instance fields
.field private ctx:Landroid/content/Context;

.field public locale:Ljava/util/Locale;

.field public localeTile:Linstafel/app/ui/TileLarge;


# direct methods
.method public constructor <init>(Landroid/content/Context;Ljava/util/Locale;)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Linstafel/app/utils/localization/LocaleInfoTile;->ctx:Landroid/content/Context;

    iput-object p2, p0, Linstafel/app/utils/localization/LocaleInfoTile;->locale:Ljava/util/Locale;

    invoke-direct {p0}, Linstafel/app/utils/localization/LocaleInfoTile;->createLangTile()Linstafel/app/ui/TileLarge;

    move-result-object p1

    iput-object p1, p0, Linstafel/app/utils/localization/LocaleInfoTile;->localeTile:Linstafel/app/ui/TileLarge;

    return-void
.end method

.method private createLangTile()Linstafel/app/ui/TileLarge;
    .locals 4

    new-instance v0, Linstafel/app/ui/TileLarge;

    iget-object v1, p0, Linstafel/app/utils/localization/LocaleInfoTile;->ctx:Landroid/content/Context;

    invoke-direct {v0, v1}, Linstafel/app/ui/TileLarge;-><init>(Landroid/content/Context;)V

    new-instance v1, Landroid/widget/LinearLayout$LayoutParams;

    const/4 v2, -0x1

    const/4 v3, -0x2

    invoke-direct {v1, v2, v3}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    invoke-virtual {v0, v1}, Linstafel/app/ui/TileLarge;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    iget-object v1, p0, Linstafel/app/utils/localization/LocaleInfoTile;->locale:Ljava/util/Locale;

    invoke-virtual {v1, v1}, Ljava/util/Locale;->getDisplayLanguage(Ljava/util/Locale;)Ljava/lang/String;

    move-result-object v1

    invoke-static {v1}, Linstafel/app/utils/GeneralFn;->capitalizeFirstLetter(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Linstafel/app/ui/TileLarge;->setTitleText(Ljava/lang/String;)V

    iget-object v1, p0, Linstafel/app/utils/localization/LocaleInfoTile;->locale:Ljava/util/Locale;

    invoke-virtual {v1, v1}, Ljava/util/Locale;->getDisplayCountry(Ljava/util/Locale;)Ljava/lang/String;

    move-result-object v1

    invoke-static {v1}, Linstafel/app/utils/GeneralFn;->capitalizeFirstLetter(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Linstafel/app/ui/TileLarge;->setSubtitleText(Ljava/lang/String;)V

    sget v1, Linstafel/app/R$drawable;->ifl_language:I

    invoke-virtual {v0, v1}, Linstafel/app/ui/TileLarge;->setIconRes(I)V

    const/4 v1, 0x1

    invoke-virtual {v0, v1}, Linstafel/app/ui/TileLarge;->setIconTint(Z)V

    const-string v1, "visible"

    invoke-virtual {v0, v1}, Linstafel/app/ui/TileLarge;->setSpaceBottom(Ljava/lang/String;)V

    const-string v1, "gone"

    invoke-virtual {v0, v1}, Linstafel/app/ui/TileLarge;->setVisiblitySubIcon(Ljava/lang/String;)V

    sget v1, Linstafel/app/R$drawable;->ifl_tick:I

    invoke-virtual {v0, v1}, Linstafel/app/ui/TileLarge;->setSubIconRes(I)V

    return-object v0
.end method


# virtual methods
.method public setTickStatus(Z)V
    .locals 1

    iget-object v0, p0, Linstafel/app/utils/localization/LocaleInfoTile;->localeTile:Linstafel/app/ui/TileLarge;

    if-eqz p1, :cond_0

    const-string p1, "visible"

    goto :goto_0

    :cond_0
    const-string p1, "gone"

    :goto_0
    invoke-virtual {v0, p1}, Linstafel/app/ui/TileLarge;->setVisiblitySubIcon(Ljava/lang/String;)V

    return-void
.end method

.method public setTileVisibility(Z)V
    .locals 1

    iget-object v0, p0, Linstafel/app/utils/localization/LocaleInfoTile;->localeTile:Linstafel/app/ui/TileLarge;

    if-eqz p1, :cond_0

    const/4 p1, 0x0

    goto :goto_0

    :cond_0
    const/16 p1, 0x8

    :goto_0
    invoke-virtual {v0, p1}, Linstafel/app/ui/TileLarge;->setVisibility(I)V

    return-void
.end method
