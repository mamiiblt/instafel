.class public Linstafel/app/activity/ifl_a_ota;
.super Landroidx/appcompat/app/AppCompatActivity;
.source "ifl_a_ota.java"


# instance fields
.field private notificationOtaManager:Linstafel/app/managers/NotificationOtaManager;

.field private preferenceManager:Linstafel/app/managers/PreferenceManager;

.field private switchView:Landroid/widget/Switch;

.field private switchViewBackground:Landroid/widget/Switch;

.field private tileBackgroundDownload:Linstafel/app/ui/TileLargeSwitch;

.field private tileCheck:Linstafel/app/ui/TileLarge;

.field private tileFreq:Linstafel/app/ui/TileLarge;

.field private tileSetting:Linstafel/app/ui/TileLargeSwitch;


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Landroidx/appcompat/app/AppCompatActivity;-><init>()V

    return-void
.end method

.method private disablePage()V
    .locals 2

    iget-object v0, p0, Linstafel/app/activity/ifl_a_ota;->switchView:Landroid/widget/Switch;

    const/4 v1, 0x0

    invoke-virtual {v0, v1}, Landroid/widget/Switch;->setChecked(Z)V

    iget-object v0, p0, Linstafel/app/activity/ifl_a_ota;->tileCheck:Linstafel/app/ui/TileLarge;

    const/16 v1, 0x8

    invoke-virtual {v0, v1}, Linstafel/app/ui/TileLarge;->setVisibility(I)V

    iget-object v0, p0, Linstafel/app/activity/ifl_a_ota;->tileBackgroundDownload:Linstafel/app/ui/TileLargeSwitch;

    invoke-virtual {v0, v1}, Linstafel/app/ui/TileLargeSwitch;->setVisibility(I)V

    iget-object v0, p0, Linstafel/app/activity/ifl_a_ota;->tileFreq:Linstafel/app/ui/TileLarge;

    invoke-virtual {v0, v1}, Linstafel/app/ui/TileLarge;->setVisibility(I)V

    return-void
.end method

.method static synthetic lambda$onCreate$5(Landroid/app/Dialog;Landroid/view/View;)V
    .locals 0

    invoke-virtual {p0}, Landroid/app/Dialog;->dismiss()V

    return-void
.end method


# virtual methods
.method public enableDisableBDownloadFeature(Z)V
    .locals 3

    const/4 v0, 0x0

    if-eqz p1, :cond_2

    sget p1, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v1, 0x21

    const/4 v2, 0x1

    if-lt p1, v1, :cond_1

    const-string p1, "android.permission.POST_NOTIFICATIONS"

    invoke-virtual {p0, p1}, Linstafel/app/activity/ifl_a_ota;->checkSelfPermission(Ljava/lang/String;)I

    move-result v1

    if-eqz v1, :cond_0

    new-array v1, v2, [Ljava/lang/String;

    aput-object p1, v1, v0

    invoke-virtual {p0, v1, v2}, Linstafel/app/activity/ifl_a_ota;->requestPermissions([Ljava/lang/String;I)V

    iget-object p1, p0, Linstafel/app/activity/ifl_a_ota;->switchViewBackground:Landroid/widget/Switch;

    invoke-virtual {p1, v0}, Landroid/widget/Switch;->setChecked(Z)V

    return-void

    :cond_0
    iget-object p1, p0, Linstafel/app/activity/ifl_a_ota;->preferenceManager:Linstafel/app/managers/PreferenceManager;

    sget-object v0, Linstafel/app/utils/types/PreferenceKeys;->ifl_ota_background_enable:Ljava/lang/String;

    invoke-virtual {p1, v0, v2}, Linstafel/app/managers/PreferenceManager;->setPreferenceBoolean(Ljava/lang/String;Z)V

    iget-object p1, p0, Linstafel/app/activity/ifl_a_ota;->notificationOtaManager:Linstafel/app/managers/NotificationOtaManager;

    invoke-virtual {p1}, Linstafel/app/managers/NotificationOtaManager;->createNotificationChannel()V

    iget-object p1, p0, Linstafel/app/activity/ifl_a_ota;->switchViewBackground:Landroid/widget/Switch;

    invoke-virtual {p1, v2}, Landroid/widget/Switch;->setChecked(Z)V

    return-void

    :cond_1
    iget-object p1, p0, Linstafel/app/activity/ifl_a_ota;->preferenceManager:Linstafel/app/managers/PreferenceManager;

    sget-object v0, Linstafel/app/utils/types/PreferenceKeys;->ifl_ota_background_enable:Ljava/lang/String;

    invoke-virtual {p1, v0, v2}, Linstafel/app/managers/PreferenceManager;->setPreferenceBoolean(Ljava/lang/String;Z)V

    iget-object p1, p0, Linstafel/app/activity/ifl_a_ota;->notificationOtaManager:Linstafel/app/managers/NotificationOtaManager;

    invoke-virtual {p1}, Linstafel/app/managers/NotificationOtaManager;->createNotificationChannel()V

    iget-object p1, p0, Linstafel/app/activity/ifl_a_ota;->switchViewBackground:Landroid/widget/Switch;

    invoke-virtual {p1, v2}, Landroid/widget/Switch;->setChecked(Z)V

    return-void

    :cond_2
    iget-object p1, p0, Linstafel/app/activity/ifl_a_ota;->preferenceManager:Linstafel/app/managers/PreferenceManager;

    sget-object v1, Linstafel/app/utils/types/PreferenceKeys;->ifl_ota_background_enable:Ljava/lang/String;

    invoke-virtual {p1, v1, v0}, Linstafel/app/managers/PreferenceManager;->setPreferenceBoolean(Ljava/lang/String;Z)V

    iget-object p1, p0, Linstafel/app/activity/ifl_a_ota;->notificationOtaManager:Linstafel/app/managers/NotificationOtaManager;

    invoke-virtual {p1}, Linstafel/app/managers/NotificationOtaManager;->createNotificationChannel()V

    iget-object p1, p0, Linstafel/app/activity/ifl_a_ota;->switchViewBackground:Landroid/widget/Switch;

    invoke-virtual {p1, v0}, Landroid/widget/Switch;->setChecked(Z)V

    return-void
.end method

.method public enableDisableOtaFeature(Z)V
    .locals 2

    if-eqz p1, :cond_1

    invoke-static {p0}, Linstafel/app/managers/PermissionManager;->checkPermission(Landroid/app/Activity;)Z

    move-result p1

    if-eqz p1, :cond_0

    invoke-virtual {p0}, Linstafel/app/activity/ifl_a_ota;->enablePage()V

    iget-object p1, p0, Linstafel/app/activity/ifl_a_ota;->preferenceManager:Linstafel/app/managers/PreferenceManager;

    sget-object v0, Linstafel/app/utils/types/PreferenceKeys;->ifl_ota_setting:Ljava/lang/String;

    const/4 v1, 0x1

    invoke-virtual {p1, v0, v1}, Linstafel/app/managers/PreferenceManager;->setPreferenceBoolean(Ljava/lang/String;Z)V

    return-void

    :cond_0
    invoke-direct {p0}, Linstafel/app/activity/ifl_a_ota;->disablePage()V

    invoke-static {p0}, Linstafel/app/managers/PermissionManager;->requestInstallPermission(Landroid/app/Activity;)V

    return-void

    :cond_1
    invoke-direct {p0}, Linstafel/app/activity/ifl_a_ota;->disablePage()V

    iget-object p1, p0, Linstafel/app/activity/ifl_a_ota;->preferenceManager:Linstafel/app/managers/PreferenceManager;

    sget-object v0, Linstafel/app/utils/types/PreferenceKeys;->ifl_ota_setting:Ljava/lang/String;

    const/4 v1, 0x0

    invoke-virtual {p1, v0, v1}, Linstafel/app/managers/PreferenceManager;->setPreferenceBoolean(Ljava/lang/String;Z)V

    return-void
.end method

.method public enablePage()V
    .locals 2

    iget-object v0, p0, Linstafel/app/activity/ifl_a_ota;->switchView:Landroid/widget/Switch;

    const/4 v1, 0x1

    invoke-virtual {v0, v1}, Landroid/widget/Switch;->setChecked(Z)V

    iget-object v0, p0, Linstafel/app/activity/ifl_a_ota;->tileCheck:Linstafel/app/ui/TileLarge;

    const/4 v1, 0x0

    invoke-virtual {v0, v1}, Linstafel/app/ui/TileLarge;->setVisibility(I)V

    iget-object v0, p0, Linstafel/app/activity/ifl_a_ota;->tileBackgroundDownload:Linstafel/app/ui/TileLargeSwitch;

    invoke-virtual {v0, v1}, Linstafel/app/ui/TileLargeSwitch;->setVisibility(I)V

    iget-object v0, p0, Linstafel/app/activity/ifl_a_ota;->tileFreq:Linstafel/app/ui/TileLarge;

    invoke-virtual {v0, v1}, Linstafel/app/ui/TileLarge;->setVisibility(I)V

    return-void
.end method

.method synthetic lambda$onCreate$0$instafel-app-activity-ifl_a_ota(Landroid/view/View;)V
    .locals 0

    const-string p1, "https://instafel.mamii.dev/about_updater"

    invoke-static {p0, p1}, Linstafel/app/utils/GeneralFn;->openInWebBrowser(Landroid/content/Context;Ljava/lang/String;)V

    return-void
.end method

.method synthetic lambda$onCreate$1$instafel-app-activity-ifl_a_ota(Landroid/view/View;)V
    .locals 0

    iget-object p1, p0, Linstafel/app/activity/ifl_a_ota;->switchViewBackground:Landroid/widget/Switch;

    invoke-virtual {p1}, Landroid/widget/Switch;->isChecked()Z

    move-result p1

    xor-int/lit8 p1, p1, 0x1

    invoke-virtual {p0, p1}, Linstafel/app/activity/ifl_a_ota;->enableDisableBDownloadFeature(Z)V

    return-void
.end method

.method synthetic lambda$onCreate$2$instafel-app-activity-ifl_a_ota(Landroid/widget/CompoundButton;Z)V
    .locals 0

    invoke-virtual {p0, p2}, Linstafel/app/activity/ifl_a_ota;->enableDisableBDownloadFeature(Z)V

    return-void
.end method

.method synthetic lambda$onCreate$3$instafel-app-activity-ifl_a_ota(Landroid/view/View;)V
    .locals 3

    sget-boolean p1, Linstafel/app/InstafelEnv;->PRODUCTION_MODE:Z

    if-eqz p1, :cond_0

    iget-object p1, p0, Linstafel/app/activity/ifl_a_ota;->switchView:Landroid/widget/Switch;

    invoke-virtual {p1}, Landroid/widget/Switch;->isChecked()Z

    move-result p1

    xor-int/lit8 p1, p1, 0x1

    invoke-virtual {p0, p1}, Linstafel/app/activity/ifl_a_ota;->enableDisableOtaFeature(Z)V

    iget-object p1, p0, Linstafel/app/activity/ifl_a_ota;->preferenceManager:Linstafel/app/managers/PreferenceManager;

    sget-object v0, Linstafel/app/utils/types/PreferenceKeys;->ifl_ota_last_check:Ljava/lang/String;

    const-wide/16 v1, 0x0

    invoke-virtual {p1, v0, v1, v2}, Linstafel/app/managers/PreferenceManager;->setPreferenceLong(Ljava/lang/String;J)V

    iget-object p1, p0, Linstafel/app/activity/ifl_a_ota;->tileCheck:Linstafel/app/ui/TileLarge;

    invoke-static {}, Ljava/util/Locale;->getDefault()Ljava/util/Locale;

    move-result-object v0

    invoke-static {p0, v0}, Linstafel/app/ota/LastCheck;->get(Landroid/app/Activity;Ljava/util/Locale;)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p1, v0}, Linstafel/app/ui/TileLarge;->setSubtitleText(Ljava/lang/String;)V

    return-void

    :cond_0
    const-string p1, "This is not an production build."

    const/4 v0, 0x0

    invoke-static {p0, p1, v0}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object p1

    invoke-virtual {p1}, Landroid/widget/Toast;->show()V

    return-void
.end method

.method synthetic lambda$onCreate$4$instafel-app-activity-ifl_a_ota(Landroid/widget/CompoundButton;Z)V
    .locals 2

    sget-boolean p1, Linstafel/app/InstafelEnv;->PRODUCTION_MODE:Z

    if-eqz p1, :cond_0

    invoke-virtual {p0, p2}, Linstafel/app/activity/ifl_a_ota;->enableDisableOtaFeature(Z)V

    iget-object p1, p0, Linstafel/app/activity/ifl_a_ota;->preferenceManager:Linstafel/app/managers/PreferenceManager;

    sget-object p2, Linstafel/app/utils/types/PreferenceKeys;->ifl_ota_last_check:Ljava/lang/String;

    const-wide/16 v0, 0x0

    invoke-virtual {p1, p2, v0, v1}, Linstafel/app/managers/PreferenceManager;->setPreferenceLong(Ljava/lang/String;J)V

    iget-object p1, p0, Linstafel/app/activity/ifl_a_ota;->tileCheck:Linstafel/app/ui/TileLarge;

    invoke-static {}, Ljava/util/Locale;->getDefault()Ljava/util/Locale;

    move-result-object p2

    invoke-static {p0, p2}, Linstafel/app/ota/LastCheck;->get(Landroid/app/Activity;Ljava/util/Locale;)Ljava/lang/String;

    move-result-object p2

    invoke-virtual {p1, p2}, Linstafel/app/ui/TileLarge;->setSubtitleText(Ljava/lang/String;)V

    return-void

    :cond_0
    const-string p1, "This is not an production build."

    const/4 p2, 0x0

    invoke-static {p0, p1, p2}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object p1

    invoke-virtual {p1}, Landroid/widget/Toast;->show()V

    return-void
.end method

.method synthetic lambda$onCreate$6$instafel-app-activity-ifl_a_ota(Landroid/widget/Spinner;Landroid/app/Dialog;Landroid/view/View;)V
    .locals 0

    invoke-virtual {p1}, Landroid/widget/Spinner;->getSelectedItemPosition()I

    move-result p1

    invoke-static {p0, p1}, Linstafel/app/managers/FrequencyManager;->setFreq(Landroid/content/Context;I)V

    iget-object p1, p0, Linstafel/app/activity/ifl_a_ota;->tileFreq:Linstafel/app/ui/TileLarge;

    invoke-static {p0}, Linstafel/app/managers/FrequencyManager;->getFreq(Landroid/content/Context;)Ljava/lang/String;

    move-result-object p3

    invoke-virtual {p1, p3}, Linstafel/app/ui/TileLarge;->setSubtitleText(Ljava/lang/String;)V

    invoke-virtual {p2}, Landroid/app/Dialog;->dismiss()V

    return-void
.end method

.method synthetic lambda$onCreate$7$instafel-app-activity-ifl_a_ota(Landroid/view/View;)V
    .locals 4

    new-instance p1, Landroid/app/Dialog;

    invoke-direct {p1, p0}, Landroid/app/Dialog;-><init>(Landroid/content/Context;)V

    sget v0, Linstafel/app/R$layout;->ifl_dg_ota_set_freq:I

    invoke-virtual {p1, v0}, Landroid/app/Dialog;->setContentView(I)V

    invoke-virtual {p1}, Landroid/app/Dialog;->getWindow()Landroid/view/Window;

    move-result-object v0

    const/4 v1, -0x2

    invoke-virtual {v0, v1, v1}, Landroid/view/Window;->setLayout(II)V

    invoke-virtual {p1}, Landroid/app/Dialog;->getWindow()Landroid/view/Window;

    move-result-object v0

    sget v1, Linstafel/app/R$drawable;->ifl_dg_ota_background:I

    invoke-virtual {p0, v1}, Linstafel/app/activity/ifl_a_ota;->getDrawable(I)Landroid/graphics/drawable/Drawable;

    move-result-object v1

    invoke-virtual {v0, v1}, Landroid/view/Window;->setBackgroundDrawable(Landroid/graphics/drawable/Drawable;)V

    const/4 v0, 0x0

    invoke-virtual {p1, v0}, Landroid/app/Dialog;->setCancelable(Z)V

    const/4 v1, 0x6

    new-array v1, v1, [Ljava/lang/String;

    sget v2, Linstafel/app/R$string;->ifl_a5_dia_freq_00:I

    invoke-virtual {p0, v2}, Linstafel/app/activity/ifl_a_ota;->getString(I)Ljava/lang/String;

    move-result-object v2

    aput-object v2, v1, v0

    sget v0, Linstafel/app/R$string;->ifl_a5_dia_freq_01:I

    invoke-virtual {p0, v0}, Linstafel/app/activity/ifl_a_ota;->getString(I)Ljava/lang/String;

    move-result-object v0

    const/4 v2, 0x1

    aput-object v0, v1, v2

    sget v0, Linstafel/app/R$string;->ifl_a5_dia_freq_02:I

    invoke-virtual {p0, v0}, Linstafel/app/activity/ifl_a_ota;->getString(I)Ljava/lang/String;

    move-result-object v0

    const/4 v2, 0x2

    aput-object v0, v1, v2

    sget v0, Linstafel/app/R$string;->ifl_a5_dia_freq_03:I

    invoke-virtual {p0, v0}, Linstafel/app/activity/ifl_a_ota;->getString(I)Ljava/lang/String;

    move-result-object v0

    const/4 v2, 0x3

    aput-object v0, v1, v2

    sget v0, Linstafel/app/R$string;->ifl_a5_dia_freq_04:I

    invoke-virtual {p0, v0}, Linstafel/app/activity/ifl_a_ota;->getString(I)Ljava/lang/String;

    move-result-object v0

    const/4 v2, 0x4

    aput-object v0, v1, v2

    sget v0, Linstafel/app/R$string;->ifl_a5_dia_freq_05:I

    invoke-virtual {p0, v0}, Linstafel/app/activity/ifl_a_ota;->getString(I)Ljava/lang/String;

    move-result-object v0

    const/4 v2, 0x5

    aput-object v0, v1, v2

    sget v0, Linstafel/app/R$id;->ifl_dialog_spinner:I

    invoke-virtual {p1, v0}, Landroid/app/Dialog;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/Spinner;

    new-instance v2, Landroid/widget/ArrayAdapter;

    const v3, 0x1090008

    invoke-direct {v2, p0, v3, v1}, Landroid/widget/ArrayAdapter;-><init>(Landroid/content/Context;I[Ljava/lang/Object;)V

    const v1, 0x1090009

    invoke-virtual {v2, v1}, Landroid/widget/ArrayAdapter;->setDropDownViewResource(I)V

    invoke-virtual {v0, v2}, Landroid/widget/Spinner;->setAdapter(Landroid/widget/SpinnerAdapter;)V

    invoke-static {p0}, Linstafel/app/managers/FrequencyManager;->getFreqId(Landroid/content/Context;)I

    move-result v1

    invoke-virtual {v0, v1}, Landroid/widget/Spinner;->setSelection(I)V

    sget v1, Linstafel/app/R$id;->ifl_dg_button_negative:I

    invoke-virtual {p1, v1}, Landroid/app/Dialog;->findViewById(I)Landroid/view/View;

    move-result-object v1

    check-cast v1, Landroid/widget/LinearLayout;

    sget v2, Linstafel/app/R$id;->ifl_dg_button_pozitive:I

    invoke-virtual {p1, v2}, Landroid/app/Dialog;->findViewById(I)Landroid/view/View;

    move-result-object v2

    check-cast v2, Landroid/widget/LinearLayout;

    new-instance v3, Linstafel/app/activity/ifl_a_ota$$ExternalSyntheticLambda6;

    invoke-direct {v3, p1}, Linstafel/app/activity/ifl_a_ota$$ExternalSyntheticLambda6;-><init>(Landroid/app/Dialog;)V

    invoke-virtual {v1, v3}, Landroid/widget/LinearLayout;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    new-instance v1, Linstafel/app/activity/ifl_a_ota$$ExternalSyntheticLambda7;

    invoke-direct {v1, p0, v0, p1}, Linstafel/app/activity/ifl_a_ota$$ExternalSyntheticLambda7;-><init>(Linstafel/app/activity/ifl_a_ota;Landroid/widget/Spinner;Landroid/app/Dialog;)V

    invoke-virtual {v2, v1}, Landroid/widget/LinearLayout;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    invoke-virtual {p1}, Landroid/app/Dialog;->show()V

    return-void
.end method

.method protected onActivityResult(IILandroid/content/Intent;)V
    .locals 0

    invoke-super {p0, p1, p2, p3}, Landroidx/appcompat/app/AppCompatActivity;->onActivityResult(IILandroid/content/Intent;)V

    invoke-static {p0}, Linstafel/app/managers/PermissionManager;->checkPermission(Landroid/app/Activity;)Z

    move-result p1

    if-eqz p1, :cond_0

    invoke-virtual {p0}, Linstafel/app/activity/ifl_a_ota;->enablePage()V

    iget-object p1, p0, Linstafel/app/activity/ifl_a_ota;->preferenceManager:Linstafel/app/managers/PreferenceManager;

    sget-object p2, Linstafel/app/utils/types/PreferenceKeys;->ifl_ota_setting:Ljava/lang/String;

    const/4 p3, 0x1

    invoke-virtual {p1, p2, p3}, Linstafel/app/managers/PreferenceManager;->setPreferenceBoolean(Ljava/lang/String;Z)V

    return-void

    :cond_0
    invoke-direct {p0}, Linstafel/app/activity/ifl_a_ota;->disablePage()V

    iget-object p1, p0, Linstafel/app/activity/ifl_a_ota;->preferenceManager:Linstafel/app/managers/PreferenceManager;

    sget-object p2, Linstafel/app/utils/types/PreferenceKeys;->ifl_ota_setting:Ljava/lang/String;

    const/4 p3, 0x0

    invoke-virtual {p1, p2, p3}, Linstafel/app/managers/PreferenceManager;->setPreferenceBoolean(Ljava/lang/String;Z)V

    return-void
.end method

.method protected onCreate(Landroid/os/Bundle;)V
    .locals 3

    invoke-super {p0, p1}, Landroidx/appcompat/app/AppCompatActivity;->onCreate(Landroid/os/Bundle;)V

    invoke-static {p0}, Linstafel/app/utils/GeneralFn;->updateIflUi(Landroidx/activity/ComponentActivity;)V

    const/4 p1, 0x0

    invoke-static {p1}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v0

    invoke-static {p0, v0}, Linstafel/app/utils/localization/LocalizationUtils;->updateIflLocale(Landroid/app/Activity;Ljava/lang/Boolean;)V

    sget v0, Linstafel/app/R$layout;->ifl_at_ota:I

    invoke-virtual {p0, v0}, Linstafel/app/activity/ifl_a_ota;->setContentView(I)V

    new-instance v0, Linstafel/app/managers/NotificationOtaManager;

    invoke-direct {v0, p0}, Linstafel/app/managers/NotificationOtaManager;-><init>(Landroid/content/Context;)V

    iput-object v0, p0, Linstafel/app/activity/ifl_a_ota;->notificationOtaManager:Linstafel/app/managers/NotificationOtaManager;

    new-instance v0, Linstafel/app/managers/PreferenceManager;

    invoke-direct {v0, p0}, Linstafel/app/managers/PreferenceManager;-><init>(Landroid/content/Context;)V

    iput-object v0, p0, Linstafel/app/activity/ifl_a_ota;->preferenceManager:Linstafel/app/managers/PreferenceManager;

    sget v0, Linstafel/app/R$id;->ifl_tile_ota_check:I

    invoke-virtual {p0, v0}, Linstafel/app/activity/ifl_a_ota;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Linstafel/app/ui/TileLarge;

    iput-object v0, p0, Linstafel/app/activity/ifl_a_ota;->tileCheck:Linstafel/app/ui/TileLarge;

    sget v0, Linstafel/app/R$id;->ifl_tile_ota_freq:I

    invoke-virtual {p0, v0}, Linstafel/app/activity/ifl_a_ota;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Linstafel/app/ui/TileLarge;

    iput-object v0, p0, Linstafel/app/activity/ifl_a_ota;->tileFreq:Linstafel/app/ui/TileLarge;

    sget v0, Linstafel/app/R$id;->ifl_tile_ota_enable_updates:I

    invoke-virtual {p0, v0}, Linstafel/app/activity/ifl_a_ota;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Linstafel/app/ui/TileLargeSwitch;

    iput-object v0, p0, Linstafel/app/activity/ifl_a_ota;->tileSetting:Linstafel/app/ui/TileLargeSwitch;

    sget v0, Linstafel/app/R$id;->ifl_tile_ota_background_download:I

    invoke-virtual {p0, v0}, Linstafel/app/activity/ifl_a_ota;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Linstafel/app/ui/TileLargeSwitch;

    iput-object v0, p0, Linstafel/app/activity/ifl_a_ota;->tileBackgroundDownload:Linstafel/app/ui/TileLargeSwitch;

    invoke-virtual {v0}, Linstafel/app/ui/TileLargeSwitch;->getSwitchView()Landroid/widget/Switch;

    move-result-object v0

    iput-object v0, p0, Linstafel/app/activity/ifl_a_ota;->switchViewBackground:Landroid/widget/Switch;

    iget-object v0, p0, Linstafel/app/activity/ifl_a_ota;->tileSetting:Linstafel/app/ui/TileLargeSwitch;

    invoke-virtual {v0}, Linstafel/app/ui/TileLargeSwitch;->getSwitchView()Landroid/widget/Switch;

    move-result-object v0

    iput-object v0, p0, Linstafel/app/activity/ifl_a_ota;->switchView:Landroid/widget/Switch;

    sget v0, Linstafel/app/R$id;->ifl_tile_ota_instafel_updater:I

    invoke-virtual {p0, v0}, Linstafel/app/activity/ifl_a_ota;->findViewById(I)Landroid/view/View;

    move-result-object v0

    new-instance v1, Linstafel/app/activity/ifl_a_ota$$ExternalSyntheticLambda0;

    invoke-direct {v1, p0}, Linstafel/app/activity/ifl_a_ota$$ExternalSyntheticLambda0;-><init>(Linstafel/app/activity/ifl_a_ota;)V

    invoke-virtual {v0, v1}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    iget-object v0, p0, Linstafel/app/activity/ifl_a_ota;->preferenceManager:Linstafel/app/managers/PreferenceManager;

    sget-object v1, Linstafel/app/utils/types/PreferenceKeys;->ifl_ota_setting:Ljava/lang/String;

    invoke-virtual {v0, v1, p1}, Linstafel/app/managers/PreferenceManager;->getPreferenceBoolean(Ljava/lang/String;Z)Ljava/lang/Boolean;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v0

    if-eqz v0, :cond_0

    invoke-virtual {p0}, Linstafel/app/activity/ifl_a_ota;->enablePage()V

    goto :goto_0

    :cond_0
    invoke-direct {p0}, Linstafel/app/activity/ifl_a_ota;->disablePage()V

    iget-object v0, p0, Linstafel/app/activity/ifl_a_ota;->tileFreq:Linstafel/app/ui/TileLarge;

    const/16 v1, 0x8

    invoke-virtual {v0, v1}, Linstafel/app/ui/TileLarge;->setVisibility(I)V

    iget-object v0, p0, Linstafel/app/activity/ifl_a_ota;->tileCheck:Linstafel/app/ui/TileLarge;

    invoke-virtual {v0, v1}, Linstafel/app/ui/TileLarge;->setVisibility(I)V

    iget-object v0, p0, Linstafel/app/activity/ifl_a_ota;->tileBackgroundDownload:Linstafel/app/ui/TileLargeSwitch;

    invoke-virtual {v0, v1}, Linstafel/app/ui/TileLargeSwitch;->setVisibility(I)V

    :goto_0
    iget-object v0, p0, Linstafel/app/activity/ifl_a_ota;->switchViewBackground:Landroid/widget/Switch;

    iget-object v1, p0, Linstafel/app/activity/ifl_a_ota;->preferenceManager:Linstafel/app/managers/PreferenceManager;

    sget-object v2, Linstafel/app/utils/types/PreferenceKeys;->ifl_ota_background_enable:Ljava/lang/String;

    invoke-virtual {v1, v2, p1}, Linstafel/app/managers/PreferenceManager;->getPreferenceBoolean(Ljava/lang/String;Z)Ljava/lang/Boolean;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v1

    invoke-virtual {v0, v1}, Landroid/widget/Switch;->setChecked(Z)V

    iget-object v0, p0, Linstafel/app/activity/ifl_a_ota;->switchView:Landroid/widget/Switch;

    iget-object v1, p0, Linstafel/app/activity/ifl_a_ota;->preferenceManager:Linstafel/app/managers/PreferenceManager;

    sget-object v2, Linstafel/app/utils/types/PreferenceKeys;->ifl_ota_setting:Ljava/lang/String;

    invoke-virtual {v1, v2, p1}, Linstafel/app/managers/PreferenceManager;->getPreferenceBoolean(Ljava/lang/String;Z)Ljava/lang/Boolean;

    move-result-object p1

    invoke-virtual {p1}, Ljava/lang/Boolean;->booleanValue()Z

    move-result p1

    invoke-virtual {v0, p1}, Landroid/widget/Switch;->setChecked(Z)V

    iget-object p1, p0, Linstafel/app/activity/ifl_a_ota;->tileBackgroundDownload:Linstafel/app/ui/TileLargeSwitch;

    new-instance v0, Linstafel/app/activity/ifl_a_ota$$ExternalSyntheticLambda1;

    invoke-direct {v0, p0}, Linstafel/app/activity/ifl_a_ota$$ExternalSyntheticLambda1;-><init>(Linstafel/app/activity/ifl_a_ota;)V

    invoke-virtual {p1, v0}, Linstafel/app/ui/TileLargeSwitch;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    iget-object p1, p0, Linstafel/app/activity/ifl_a_ota;->switchViewBackground:Landroid/widget/Switch;

    new-instance v0, Linstafel/app/activity/ifl_a_ota$$ExternalSyntheticLambda2;

    invoke-direct {v0, p0}, Linstafel/app/activity/ifl_a_ota$$ExternalSyntheticLambda2;-><init>(Linstafel/app/activity/ifl_a_ota;)V

    invoke-virtual {p1, v0}, Landroid/widget/Switch;->setOnCheckedChangeListener(Landroid/widget/CompoundButton$OnCheckedChangeListener;)V

    iget-object p1, p0, Linstafel/app/activity/ifl_a_ota;->tileSetting:Linstafel/app/ui/TileLargeSwitch;

    new-instance v0, Linstafel/app/activity/ifl_a_ota$$ExternalSyntheticLambda3;

    invoke-direct {v0, p0}, Linstafel/app/activity/ifl_a_ota$$ExternalSyntheticLambda3;-><init>(Linstafel/app/activity/ifl_a_ota;)V

    invoke-virtual {p1, v0}, Linstafel/app/ui/TileLargeSwitch;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    iget-object p1, p0, Linstafel/app/activity/ifl_a_ota;->switchView:Landroid/widget/Switch;

    new-instance v0, Linstafel/app/activity/ifl_a_ota$$ExternalSyntheticLambda4;

    invoke-direct {v0, p0}, Linstafel/app/activity/ifl_a_ota$$ExternalSyntheticLambda4;-><init>(Linstafel/app/activity/ifl_a_ota;)V

    invoke-virtual {p1, v0}, Landroid/widget/Switch;->setOnCheckedChangeListener(Landroid/widget/CompoundButton$OnCheckedChangeListener;)V

    iget-object p1, p0, Linstafel/app/activity/ifl_a_ota;->tileFreq:Linstafel/app/ui/TileLarge;

    new-instance v0, Linstafel/app/activity/ifl_a_ota$$ExternalSyntheticLambda5;

    invoke-direct {v0, p0}, Linstafel/app/activity/ifl_a_ota$$ExternalSyntheticLambda5;-><init>(Linstafel/app/activity/ifl_a_ota;)V

    invoke-virtual {p1, v0}, Linstafel/app/ui/TileLarge;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    iget-object p1, p0, Linstafel/app/activity/ifl_a_ota;->tileCheck:Linstafel/app/ui/TileLarge;

    invoke-static {}, Ljava/util/Locale;->getDefault()Ljava/util/Locale;

    move-result-object v0

    invoke-static {p0, v0}, Linstafel/app/ota/LastCheck;->get(Landroid/app/Activity;Ljava/util/Locale;)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p1, v0}, Linstafel/app/ui/TileLarge;->setSubtitleText(Ljava/lang/String;)V

    iget-object p1, p0, Linstafel/app/activity/ifl_a_ota;->tileFreq:Linstafel/app/ui/TileLarge;

    invoke-static {p0}, Linstafel/app/managers/FrequencyManager;->getFreq(Landroid/content/Context;)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p1, v0}, Linstafel/app/ui/TileLarge;->setSubtitleText(Ljava/lang/String;)V

    sget p1, Linstafel/app/R$id;->ifl_tile_ota_check:I

    invoke-virtual {p0, p1}, Linstafel/app/activity/ifl_a_ota;->findViewById(I)Landroid/view/View;

    move-result-object p1

    check-cast p1, Linstafel/app/ui/TileLarge;

    invoke-static {p0, p1}, Linstafel/app/ota/CheckUpdates;->set(Landroid/app/Activity;Linstafel/app/ui/TileLarge;)V

    return-void
.end method

.method public onRequestPermissionsResult(I[Ljava/lang/String;[I)V
    .locals 10

    const/4 v0, 0x1

    if-ne p1, v0, :cond_1

    array-length v1, p3

    const/4 v2, 0x0

    if-lez v1, :cond_0

    aget v1, p3, v2

    if-nez v1, :cond_0

    iget-object v1, p0, Linstafel/app/activity/ifl_a_ota;->preferenceManager:Linstafel/app/managers/PreferenceManager;

    sget-object v2, Linstafel/app/utils/types/PreferenceKeys;->ifl_ota_background_enable:Ljava/lang/String;

    invoke-virtual {v1, v2, v0}, Linstafel/app/managers/PreferenceManager;->setPreferenceBoolean(Ljava/lang/String;Z)V

    iget-object v1, p0, Linstafel/app/activity/ifl_a_ota;->switchViewBackground:Landroid/widget/Switch;

    invoke-virtual {v1, v0}, Landroid/widget/Switch;->setChecked(Z)V

    iget-object v0, p0, Linstafel/app/activity/ifl_a_ota;->notificationOtaManager:Linstafel/app/managers/NotificationOtaManager;

    invoke-virtual {v0}, Linstafel/app/managers/NotificationOtaManager;->createNotificationChannel()V

    goto :goto_0

    :cond_0
    iget-object v0, p0, Linstafel/app/activity/ifl_a_ota;->preferenceManager:Linstafel/app/managers/PreferenceManager;

    sget-object v1, Linstafel/app/utils/types/PreferenceKeys;->ifl_ota_background_enable:Ljava/lang/String;

    invoke-virtual {v0, v1, v2}, Linstafel/app/managers/PreferenceManager;->setPreferenceBoolean(Ljava/lang/String;Z)V

    iget-object v0, p0, Linstafel/app/activity/ifl_a_ota;->switchViewBackground:Landroid/widget/Switch;

    invoke-virtual {v0, v2}, Landroid/widget/Switch;->setChecked(Z)V

    const/4 v8, 0x0

    const/4 v9, 0x0

    const-string v4, "Permission Denied"

    const-string v5, "Instafel\'s notification permission was denied. If this problem persists, do not forget to turn on notifications from the application settings."

    const-string v6, "Okay"

    const/4 v7, 0x0

    move-object v3, p0

    invoke-static/range {v3 .. v9}, Linstafel/app/utils/dialog/InstafelDialog;->createSimpleDialog(Landroid/app/Activity;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Landroid/view/View$OnClickListener;Landroid/view/View$OnClickListener;)Linstafel/app/utils/dialog/InstafelDialog;

    move-result-object v0

    invoke-virtual {v0}, Linstafel/app/utils/dialog/InstafelDialog;->show()V

    :cond_1
    :goto_0
    invoke-super {p0, p1, p2, p3}, Landroidx/appcompat/app/AppCompatActivity;->onRequestPermissionsResult(I[Ljava/lang/String;[I)V

    return-void
.end method
