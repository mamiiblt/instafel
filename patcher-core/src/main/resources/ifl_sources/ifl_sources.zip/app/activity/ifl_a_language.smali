.class public Linstafel/app/activity/ifl_a_language;
.super Landroidx/appcompat/app/AppCompatActivity;
.source "ifl_a_language.java"


# instance fields
.field private languagesArea:Landroid/widget/LinearLayout;

.field private localeTiles:Ljava/util/Map;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Map<",
            "Ljava/util/Locale;",
            "Linstafel/app/utils/localization/LocaleInfoTile;",
            ">;"
        }
    .end annotation
.end field

.field private supportedLocaleList:Landroid/os/LocaleList;

.field private tileDeviceSwitch:Landroid/widget/Switch;

.field private tileLangDevice:Linstafel/app/ui/TileLargeSwitch;


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Landroidx/appcompat/app/AppCompatActivity;-><init>()V

    return-void
.end method


# virtual methods
.method synthetic lambda$onCreate$0$instafel-app-activity-ifl_a_language(Landroid/widget/CompoundButton;Z)V
    .locals 0

    invoke-static {p0, p2}, Linstafel/app/utils/localization/LocalizationUtils;->setStateOfDevice(Landroid/app/Activity;Z)V

    return-void
.end method

.method public onBackPressed()V
    .locals 3

    new-instance v0, Linstafel/app/managers/PreferenceManager;

    invoke-direct {v0, p0}, Linstafel/app/managers/PreferenceManager;-><init>(Landroid/content/Context;)V

    sget-object v1, Linstafel/app/utils/types/PreferenceKeys;->ifl_ui_recreate:Ljava/lang/String;

    const/4 v2, 0x1

    invoke-virtual {v0, v1, v2}, Linstafel/app/managers/PreferenceManager;->setPreferenceBoolean(Ljava/lang/String;Z)V

    invoke-super {p0}, Landroidx/appcompat/app/AppCompatActivity;->onBackPressed()V

    return-void
.end method

.method protected onCreate(Landroid/os/Bundle;)V
    .locals 10

    invoke-super {p0, p1}, Landroidx/appcompat/app/AppCompatActivity;->onCreate(Landroid/os/Bundle;)V

    invoke-static {p0}, Linstafel/app/utils/GeneralFn;->updateIflUi(Landroidx/activity/ComponentActivity;)V

    const/4 p1, 0x1

    invoke-static {p1}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v0

    invoke-static {p0, v0}, Linstafel/app/utils/localization/LocalizationUtils;->updateIflLocale(Landroid/app/Activity;Ljava/lang/Boolean;)V

    sget v0, Linstafel/app/R$layout;->ifl_at_language:I

    invoke-virtual {p0, v0}, Linstafel/app/activity/ifl_a_language;->setContentView(I)V

    new-instance v0, Linstafel/app/managers/PreferenceManager;

    invoke-direct {v0, p0}, Linstafel/app/managers/PreferenceManager;-><init>(Landroid/content/Context;)V

    sget-object v1, Linstafel/app/utils/types/PreferenceKeys;->ifl_lang_rw:Ljava/lang/String;

    const-string v2, "def"

    invoke-virtual {v0, v1, v2}, Linstafel/app/managers/PreferenceManager;->getPreferenceString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    sget v1, Linstafel/app/R$id;->ifl_languages_layout:I

    invoke-virtual {p0, v1}, Linstafel/app/activity/ifl_a_language;->findViewById(I)Landroid/view/View;

    move-result-object v1

    check-cast v1, Landroid/widget/LinearLayout;

    iput-object v1, p0, Linstafel/app/activity/ifl_a_language;->languagesArea:Landroid/widget/LinearLayout;

    sget v1, Linstafel/app/R$id;->ifl_tile_lang_device:I

    invoke-virtual {p0, v1}, Linstafel/app/activity/ifl_a_language;->findViewById(I)Landroid/view/View;

    move-result-object v1

    check-cast v1, Linstafel/app/ui/TileLargeSwitch;

    iput-object v1, p0, Linstafel/app/activity/ifl_a_language;->tileLangDevice:Linstafel/app/ui/TileLargeSwitch;

    invoke-virtual {v1}, Linstafel/app/ui/TileLargeSwitch;->getSwitchView()Landroid/widget/Switch;

    move-result-object v1

    iput-object v1, p0, Linstafel/app/activity/ifl_a_language;->tileDeviceSwitch:Landroid/widget/Switch;

    new-instance v1, Ljava/util/HashMap;

    invoke-direct {v1}, Ljava/util/HashMap;-><init>()V

    iput-object v1, p0, Linstafel/app/activity/ifl_a_language;->localeTiles:Ljava/util/Map;

    invoke-static {}, Linstafel/app/InstafelEnv;->getSupportedLocaleList()Landroid/os/LocaleList;

    move-result-object v1

    iput-object v1, p0, Linstafel/app/activity/ifl_a_language;->supportedLocaleList:Landroid/os/LocaleList;

    invoke-static {p0}, Linstafel/app/utils/localization/LocalizationUtils;->getActivityLocale(Landroid/content/Context;)Ljava/util/Locale;

    move-result-object v1

    const/4 v3, 0x0

    move v4, v3

    :goto_0
    iget-object v5, p0, Linstafel/app/activity/ifl_a_language;->supportedLocaleList:Landroid/os/LocaleList;

    invoke-virtual {v5}, Landroid/os/LocaleList;->size()I

    move-result v5

    if-ge v4, v5, :cond_1

    iget-object v5, p0, Linstafel/app/activity/ifl_a_language;->supportedLocaleList:Landroid/os/LocaleList;

    invoke-virtual {v5, v4}, Landroid/os/LocaleList;->get(I)Ljava/util/Locale;

    move-result-object v5

    invoke-virtual {v1, v5}, Ljava/util/Locale;->equals(Ljava/lang/Object;)Z

    move-result v5

    const-string v6, ") "

    const-string v7, " ("

    if-eqz v5, :cond_0

    iget-object v4, p0, Linstafel/app/activity/ifl_a_language;->tileLangDevice:Linstafel/app/ui/TileLargeSwitch;

    new-instance v5, Ljava/lang/StringBuilder;

    invoke-direct {v5}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v1, v1}, Ljava/util/Locale;->getDisplayLanguage(Ljava/util/Locale;)Ljava/lang/String;

    move-result-object v8

    invoke-virtual {v5, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    const-string v8, ", "

    invoke-virtual {v5, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v1, v1}, Ljava/util/Locale;->getDisplayCountry(Ljava/util/Locale;)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v5, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    sget v5, Linstafel/app/R$string;->ifl_a6_02:I

    invoke-virtual {p0, v5}, Linstafel/app/activity/ifl_a_language;->getString(I)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v1, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v4, v1}, Linstafel/app/ui/TileLargeSwitch;->setSubtitleText(Ljava/lang/String;)V

    goto :goto_1

    :cond_0
    iget-object v5, p0, Linstafel/app/activity/ifl_a_language;->tileLangDevice:Linstafel/app/ui/TileLargeSwitch;

    new-instance v8, Ljava/lang/StringBuilder;

    invoke-direct {v8}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v1, v1}, Ljava/util/Locale;->getDisplayLanguage(Ljava/util/Locale;)Ljava/lang/String;

    move-result-object v9

    invoke-virtual {v8, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v8

    invoke-virtual {v8, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v7

    sget v8, Linstafel/app/R$string;->ifl_a6_03:I

    invoke-virtual {p0, v8}, Linstafel/app/activity/ifl_a_language;->getString(I)Ljava/lang/String;

    move-result-object v8

    invoke-virtual {v7, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v7

    invoke-virtual {v7, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v6

    invoke-virtual {v6}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v5, v6}, Linstafel/app/ui/TileLargeSwitch;->setSubtitleText(Ljava/lang/String;)V

    add-int/lit8 v4, v4, 0x1

    goto :goto_0

    :cond_1
    :goto_1
    move v1, v3

    :goto_2
    iget-object v4, p0, Linstafel/app/activity/ifl_a_language;->supportedLocaleList:Landroid/os/LocaleList;

    invoke-virtual {v4}, Landroid/os/LocaleList;->size()I

    move-result v4

    if-ge v1, v4, :cond_2

    iget-object v4, p0, Linstafel/app/activity/ifl_a_language;->supportedLocaleList:Landroid/os/LocaleList;

    invoke-virtual {v4, v1}, Landroid/os/LocaleList;->get(I)Ljava/util/Locale;

    move-result-object v4

    iget-object v5, p0, Linstafel/app/activity/ifl_a_language;->localeTiles:Ljava/util/Map;

    new-instance v6, Linstafel/app/utils/localization/LocaleInfoTile;

    invoke-direct {v6, p0, v4}, Linstafel/app/utils/localization/LocaleInfoTile;-><init>(Landroid/content/Context;Ljava/util/Locale;)V

    invoke-interface {v5, v4, v6}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    iget-object v5, p0, Linstafel/app/activity/ifl_a_language;->languagesArea:Landroid/widget/LinearLayout;

    iget-object v6, p0, Linstafel/app/activity/ifl_a_language;->localeTiles:Ljava/util/Map;

    invoke-interface {v6, v4}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Linstafel/app/utils/localization/LocaleInfoTile;

    iget-object v4, v4, Linstafel/app/utils/localization/LocaleInfoTile;->localeTile:Linstafel/app/ui/TileLarge;

    invoke-virtual {v5, v4}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    add-int/lit8 v1, v1, 0x1

    goto :goto_2

    :cond_2
    invoke-virtual {v0, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_3

    iget-object v0, p0, Linstafel/app/activity/ifl_a_language;->tileDeviceSwitch:Landroid/widget/Switch;

    invoke-virtual {v0, p1}, Landroid/widget/Switch;->setChecked(Z)V

    iget-object p1, p0, Linstafel/app/activity/ifl_a_language;->localeTiles:Ljava/util/Map;

    invoke-static {v3, p1}, Linstafel/app/utils/localization/LocalizationUtils;->setVisibilityOfAllLocales(ZLjava/util/Map;)V

    goto :goto_3

    :cond_3
    iget-object v1, p0, Linstafel/app/activity/ifl_a_language;->tileDeviceSwitch:Landroid/widget/Switch;

    invoke-virtual {v1, v3}, Landroid/widget/Switch;->setChecked(Z)V

    iget-object v1, p0, Linstafel/app/activity/ifl_a_language;->localeTiles:Ljava/util/Map;

    invoke-static {p1, v1}, Linstafel/app/utils/localization/LocalizationUtils;->setVisibilityOfAllLocales(ZLjava/util/Map;)V

    iget-object v1, p0, Linstafel/app/activity/ifl_a_language;->localeTiles:Ljava/util/Map;

    invoke-static {v0, p1, v1}, Linstafel/app/utils/localization/LocalizationUtils;->setSubIconVisibilityOfLocale(Ljava/lang/String;ZLjava/util/Map;)V

    :goto_3
    iget-object p1, p0, Linstafel/app/activity/ifl_a_language;->localeTiles:Ljava/util/Map;

    invoke-static {p0, p1}, Linstafel/app/utils/localization/LocalizationUtils;->setLanguageClickListeners(Landroid/app/Activity;Ljava/util/Map;)V

    iget-object p1, p0, Linstafel/app/activity/ifl_a_language;->tileDeviceSwitch:Landroid/widget/Switch;

    new-instance v0, Linstafel/app/activity/ifl_a_language$$ExternalSyntheticLambda0;

    invoke-direct {v0, p0}, Linstafel/app/activity/ifl_a_language$$ExternalSyntheticLambda0;-><init>(Linstafel/app/activity/ifl_a_language;)V

    invoke-virtual {p1, v0}, Landroid/widget/Switch;->setOnCheckedChangeListener(Landroid/widget/CompoundButton$OnCheckedChangeListener;)V

    return-void
.end method
