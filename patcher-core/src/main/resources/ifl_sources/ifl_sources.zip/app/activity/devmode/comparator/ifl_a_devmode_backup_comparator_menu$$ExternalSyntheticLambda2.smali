.class public final synthetic Linstafel/app/activity/devmode/comparator/ifl_a_devmode_backup_comparator_menu$$ExternalSyntheticLambda2;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Landroid/view/View$OnClickListener;


# instance fields
.field public final synthetic f$0:Linstafel/app/activity/devmode/comparator/ifl_a_devmode_backup_comparator_menu;


# direct methods
.method public synthetic constructor <init>(Linstafel/app/activity/devmode/comparator/ifl_a_devmode_backup_comparator_menu;)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Linstafel/app/activity/devmode/comparator/ifl_a_devmode_backup_comparator_menu$$ExternalSyntheticLambda2;->f$0:Linstafel/app/activity/devmode/comparator/ifl_a_devmode_backup_comparator_menu;

    return-void
.end method


# virtual methods
.method public final onClick(Landroid/view/View;)V
    .locals 1

    iget-object v0, p0, Linstafel/app/activity/devmode/comparator/ifl_a_devmode_backup_comparator_menu$$ExternalSyntheticLambda2;->f$0:Linstafel/app/activity/devmode/comparator/ifl_a_devmode_backup_comparator_menu;

    invoke-virtual {v0, p1}, Linstafel/app/activity/devmode/comparator/ifl_a_devmode_backup_comparator_menu;->lambda$onCreate$2$instafel-app-activity-devmode-comparator-ifl_a_devmode_backup_comparator_menu(Landroid/view/View;)V

    return-void
.end method
