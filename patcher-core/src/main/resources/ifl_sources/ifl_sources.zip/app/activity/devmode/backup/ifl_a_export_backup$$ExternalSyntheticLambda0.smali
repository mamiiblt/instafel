.class public final synthetic Linstafel/app/activity/devmode/backup/ifl_a_export_backup$$ExternalSyntheticLambda0;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Landroid/widget/TextView$OnEditorActionListener;


# instance fields
.field public final synthetic f$0:Linstafel/app/activity/devmode/backup/ifl_a_export_backup;


# direct methods
.method public synthetic constructor <init>(Linstafel/app/activity/devmode/backup/ifl_a_export_backup;)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Linstafel/app/activity/devmode/backup/ifl_a_export_backup$$ExternalSyntheticLambda0;->f$0:Linstafel/app/activity/devmode/backup/ifl_a_export_backup;

    return-void
.end method


# virtual methods
.method public final onEditorAction(Landroid/widget/TextView;ILandroid/view/KeyEvent;)Z
    .locals 1

    iget-object v0, p0, Linstafel/app/activity/devmode/backup/ifl_a_export_backup$$ExternalSyntheticLambda0;->f$0:Linstafel/app/activity/devmode/backup/ifl_a_export_backup;

    invoke-virtual {v0, p1, p2, p3}, Linstafel/app/activity/devmode/backup/ifl_a_export_backup;->lambda$onCreate$0$instafel-app-activity-devmode-backup-ifl_a_export_backup(Landroid/widget/TextView;ILandroid/view/KeyEvent;)Z

    move-result p1

    return p1
.end method
