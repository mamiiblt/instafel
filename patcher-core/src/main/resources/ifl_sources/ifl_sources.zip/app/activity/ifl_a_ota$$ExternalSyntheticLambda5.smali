.class public final synthetic Linstafel/app/activity/ifl_a_ota$$ExternalSyntheticLambda5;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Landroid/view/View$OnClickListener;


# instance fields
.field public final synthetic f$0:Linstafel/app/activity/ifl_a_ota;


# direct methods
.method public synthetic constructor <init>(Linstafel/app/activity/ifl_a_ota;)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Linstafel/app/activity/ifl_a_ota$$ExternalSyntheticLambda5;->f$0:Linstafel/app/activity/ifl_a_ota;

    return-void
.end method


# virtual methods
.method public final onClick(Landroid/view/View;)V
    .locals 1

    iget-object v0, p0, Linstafel/app/activity/ifl_a_ota$$ExternalSyntheticLambda5;->f$0:Linstafel/app/activity/ifl_a_ota;

    invoke-virtual {v0, p1}, Linstafel/app/activity/ifl_a_ota;->lambda$onCreate$7$instafel-app-activity-ifl_a_ota(Landroid/view/View;)V

    return-void
.end method
