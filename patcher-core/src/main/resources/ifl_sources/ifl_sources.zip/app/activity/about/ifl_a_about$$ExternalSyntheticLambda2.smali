.class public final synthetic Linstafel/app/activity/about/ifl_a_about$$ExternalSyntheticLambda2;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Landroid/view/View$OnClickListener;


# instance fields
.field public final synthetic f$0:Linstafel/app/activity/about/ifl_a_about;


# direct methods
.method public synthetic constructor <init>(Linstafel/app/activity/about/ifl_a_about;)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Linstafel/app/activity/about/ifl_a_about$$ExternalSyntheticLambda2;->f$0:Linstafel/app/activity/about/ifl_a_about;

    return-void
.end method


# virtual methods
.method public final onClick(Landroid/view/View;)V
    .locals 1

    iget-object v0, p0, Linstafel/app/activity/about/ifl_a_about$$ExternalSyntheticLambda2;->f$0:Linstafel/app/activity/about/ifl_a_about;

    invoke-virtual {v0, p1}, Linstafel/app/activity/about/ifl_a_about;->lambda$onCreate$2$instafel-app-activity-about-ifl_a_about(Landroid/view/View;)V

    return-void
.end method
