.class public final Linstafel/app/R$attr;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Linstafel/app/R;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "attr"
.end annotation


# static fields
.field public static ifl_attr_background_color:I = 0x7f030286

.field public static ifl_attr_iview_tint:I = 0x7f030287

.field public static ifl_attr_subtitle_color:I = 0x7f030288

.field public static ifl_attr_tile_color:I = 0x7f030289

.field public static ifl_attr_title_color:I = 0x7f03028a

.field public static ifl_attr_ui_enableIcon:I = 0x7f03028b

.field public static ifl_attr_ui_enableSubIcon:I = 0x7f03028c

.field public static ifl_attr_ui_iconPadding:I = 0x7f03028d

.field public static ifl_attr_ui_iconRes:I = 0x7f03028e

.field public static ifl_attr_ui_iconResTint:I = 0x7f03028f

.field public static ifl_attr_ui_spaceBottom:I = 0x7f030290

.field public static ifl_attr_ui_spaceTop:I = 0x7f030291

.field public static ifl_attr_ui_subIconRes:I = 0x7f030292

.field public static ifl_attr_ui_subtitleText:I = 0x7f030293

.field public static ifl_attr_ui_titleText:I = 0x7f030294


# direct methods
.method private constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
